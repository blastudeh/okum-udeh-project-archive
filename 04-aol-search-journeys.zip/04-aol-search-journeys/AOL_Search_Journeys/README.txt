AOL 2006 SEARCH JOURNEYS - COMPLETED ANALYSIS PACKAGE
Prepared for Okum Udeh, BHT Berlin, 8 October 2026

TOPIC
How people search: sessions, query changes and website choices in AOL 2006.

EXECUTION STATUS
The full ten-file research archive was downloaded, checksum-verified and
analyzed locally with SQL in DuckDB. All charts and reported figures are
computed results. The Exasol SQL is supplied but has not been executed in
the university VM. Exasol query/result/schema screenshots and reconciliation
with the university's installed data remain outstanding.

VERIFIED RESULTS
36,389,567 original log rows
35,389,190 retained source rows
28,037,812 proxy events (user + timestamp + exact query text)
651,655 retained anonymous users
10,493,991 sessions under a strictly greater-than-30-minute gap rule
5,459,981 single-event sessions
6,771,942 sessions with at least one recorded click

FILE MAP
scripts/download_aol.py: download full source archive and verify MD5
scripts/extract_aol.py: extract ten tab-separated files
scripts/analyze.py: complete SQL analysis and CSV exports
scripts/summarize.py: metrics and charts
sql/: Exasol staging tables, views, five analyses and validation statements
results/: aggregate CSVs, metrics and validation checks
charts/: calculated chart images
holidays_2006.csv: transcribed NY Fed holiday dates
calendar_2006.csv: derived March-May date dimension
source.json and PROVENANCE.txt: source identity, rights, transformations
requirements.txt: versions used in the local analysis

REPRODUCE
Install Python 3 and the packages in requirements.txt.
From this folder run:
  python scripts/download_aol.py
  python scripts/extract_aol.py
  python scripts/analyze.py
  python scripts/summarize.py
The source archive is approximately 391 MB compressed. Plan for several GB
of working space for extracted records, the database and temporary files.
The scripts build raw/ and analysis.duckdb locally. Do not run simultaneous
writers against the same DuckDB file. Close database clients before reruns.

METHODS
Exclude invalid keys, empty text and dash-only queries. Retain March-May.
Combine multiple rows for one event with MAX(recorded-click flag).
Use LAG and cumulative SUM to identify per-user sessions.
Run CUBE, ROLLUP, GROUPING SETS, rankings and bounded windows.
Check 15-, 30- and 60-minute session thresholds.
Use recorded dates. No per-user local timezone or success label is known.

EXASOL
Use the four SQL files in order as explained in the separate walkthrough.
Import the ten source text files once into RAW_LOG and the derived calendar
once into CALENDAR_2006. Run the validation benchmarks before substituting
course-VM results in the report. The known archive fields avoid guessed
joins against the university's unavailable star schema.

PRIVACY
Only aggregate results are included. Raw search text, user histories and
the multi-GB local database are excluded from this delivery pack.
