from pathlib import Path
import duckdb,pandas as pd,re,json,time,hashlib
root=Path(__file__).resolve().parents[1]
c=duckdb.connect(str(root/'states.duckdb'))
c.execute("SET memory_limit='5GB'; SET threads=4; SET preserve_insertion_order=false")
source_db=root/'aol_base.duckdb'
if not source_db.exists(): source_db=root.parent/'aol_project/analysis.duckdb'
c.execute("ATTACH '"+str(source_db)+"' AS aol (READ_ONLY)")
def run(sql):
 t=time.time();c.execute(sql);print(sql.splitlines()[0][:75],round(time.time()-t,1),flush=True)
def out(name,sql):
 d=c.execute(sql).df();d.to_csv(root/'results'/f'{name}.csv',index=False);return d
p=pd.read_csv(root/'data/census_original_nst_est2006_alldata.csv',dtype=str)
p=p[(p.SUMLEV=='040') & (~p.state.isin(['11','72']))].copy()
p=pd.DataFrame({'state_fips':p.state,'state_name':p.NAME,'population_2006':p.POPESTIMATE2006.astype(int),'region':p.region.map({'1':'Northeast','2':'Midwest','3':'South','4':'West'})})
p['ambiguity_flag']=p.state_name.isin(['Georgia','Washington','New York']).astype(int)
assert len(p)==50 and p.state_fips.nunique()==50
p.to_csv(root/'data/states_2006.csv',index=False)
c.register('pop_frame',p);run('CREATE OR REPLACE TABLE states AS SELECT * FROM pop_frame')
pat=r'\b('+ '|'.join(re.escape(x.lower()) for x in sorted(p.state_name,key=len,reverse=True))+r')\b'
(root/'data/matching_pattern.txt').write_text(pat)
# Match each distinct spelling once, keeping the longest state name at a position.
run("CREATE OR REPLACE TABLE texts AS SELECT DISTINCT query_text,trim(regexp_replace(lower(query_text),'[^a-z]+',' ','g')) norm FROM aol.events")
run("CREATE OR REPLACE TABLE text_matches AS SELECT query_text,norm,list_distinct(regexp_extract_all(norm, '"+pat+"',1)) state_names FROM texts")
run("CREATE OR REPLACE TABLE mentions AS SELECT e.*,m.norm,s.* FROM (SELECT query_text,norm,unnest(state_names) state_lower FROM text_matches WHERE len(state_names)>0) m JOIN aol.events e USING(query_text) JOIN states s ON lower(s.state_name)=m.state_lower")
q=out('quality',"""SELECT (SELECT count(*) FROM aol.raw) raw_rows,(SELECT count(*) FROM aol.events) all_events,
 count(*) state_event_mentions,count(distinct (user_id,search_ts,query_text)) matched_events,count(distinct user_id) matched_users,
 sum(source_rows) matched_source_rows,(SELECT sum(population_2006) FROM states) population_50 FROM mentions""")
run("""CREATE OR REPLACE TABLE state_summary AS WITH a AS (
 SELECT state_fips,count(*) mentions,sum(source_rows) source_rows,count(distinct user_id) users,count(distinct query_text) distinct_texts FROM mentions GROUP BY state_fips)
 SELECT s.*,coalesce(a.mentions,0) mentions,coalesce(a.source_rows,0) source_rows,a.users,a.distinct_texts,
 1.0*a.mentions/sum(a.mentions) OVER() mention_share,
 1.0*population_2006/sum(population_2006) OVER() population_share,
 (1.0*a.mentions/sum(a.mentions) OVER())/(1.0*population_2006/sum(population_2006) OVER()) attention_index,
 1e6*a.mentions/population_2006 mentions_per_million,
 dense_rank() OVER(ORDER BY a.mentions DESC) volume_rank
 FROM states s LEFT JOIN a USING(state_fips)""")
d=out('state_summary','SELECT * FROM state_summary ORDER BY volume_rank,state_name')
out('q1_cube',"SELECT region,state_name,grouping(region) g_region,grouping(state_name) g_state,count(*) mentions FROM mentions GROUP BY CUBE(region,state_name) ORDER BY region,state_name")
out('q2_population','SELECT * FROM state_summary ORDER BY attention_index DESC')
out('q3_rollup',"SELECT strftime(search_ts,'%Y-%m') search_month,region,state_name,grouping(strftime(search_ts,'%Y-%m')) g_month,grouping(region) g_region,grouping(state_name) g_state,count(*) mentions FROM mentions GROUP BY ROLLUP(strftime(search_ts,'%Y-%m'),region,state_name) ORDER BY search_month,region,state_name")
out('monthly',"WITH a AS(SELECT strftime(search_ts,'%Y-%m') search_month,state_name,count(*) mentions FROM mentions GROUP BY 1,2) SELECT *,dense_rank() OVER(PARTITION BY search_month ORDER BY mentions DESC) month_rank FROM a ORDER BY search_month,month_rank")
# Predeclared lexical themes, non-exclusive: word hits are not verified intent.
themes={'Tourism':r'\b(hotel|hotels|vacation|vacations|beach|beaches|resort|resorts|tourism|tourist|tourists)\b','Education':r'\b(university|universities|college|colleges|school|schools)\b','Housing':r'\b(real estate|homes|housing|apartments|apartment|realtor|realtors)\b','Government':r'\b(tax|taxes|court|courts|dmv|license|licenses|government)\b'}
(root/'data/theme_dictionary.json').write_text(json.dumps(themes,indent=2))
c.execute('CREATE OR REPLACE TABLE themes(theme VARCHAR,pattern VARCHAR)');c.executemany('INSERT INTO themes VALUES (?,?)',list(themes.items()))
run('CREATE OR REPLACE TABLE theme_hits AS SELECT m.*,t.theme FROM mentions m JOIN themes t ON regexp_matches(m.norm,t.pattern)')
out('q4_grouping_sets',"SELECT state_name,theme,grouping(state_name) g_state,grouping(theme) g_theme,count(*) hits FROM theme_hits GROUP BY GROUPING SETS((state_name,theme),(theme),()) ORDER BY state_name,theme")
out('theme_rates',"SELECT s.state_name,t.theme,count(h.theme) hits,s.mentions,1.0*count(h.theme)/s.mentions theme_share FROM state_summary s CROSS JOIN themes t LEFT JOIN theme_hits h ON h.state_fips=s.state_fips AND h.theme=t.theme GROUP BY s.state_name,t.theme,s.mentions ORDER BY s.state_name,t.theme")
stop='a an and are as at be been but by can com could do for from get had has have how i if in is it its me my of on one or our out s that the their them there these they this to us was we were what when where which who will with www you your state states new north south west east county city org net gov edu html htm http https index home page official site online'.split()
stop=sorted(set(stop)|set(' '.join(p.state_name).lower().split()))
(root/'data/stopwords.txt').write_text('\n'.join(stop))
c.execute('CREATE OR REPLACE TABLE stopwords(word VARCHAR)');c.executemany('INSERT INTO stopwords VALUES (?)',[(s,) for s in stop])
run("CREATE OR REPLACE TABLE word_hits AS SELECT state_name,user_id,search_ts,query_text,unnest(list_distinct(string_split(norm,' '))) word FROM mentions")
run("CREATE OR REPLACE TABLE word_counts AS SELECT state_name,word,count(*) mentions,count(distinct user_id) users FROM word_hits w WHERE length(word)>=3 AND NOT EXISTS(SELECT 1 FROM stopwords s WHERE s.word=w.word) GROUP BY state_name,word HAVING count(*)>=100 AND count(distinct user_id)>=50")
out('common_words',"WITH r AS(SELECT *,dense_rank() OVER(PARTITION BY state_name ORDER BY mentions DESC) word_rank FROM word_counts) SELECT * FROM r WHERE word_rank<=10 ORDER BY state_name,word_rank,word")
# All session events retained: window context includes searches without state names.
run("CREATE OR REPLACE VIEW session_flags AS SELECT n.*,CASE WHEN len(m.state_names)>0 THEN 1 ELSE 0 END has_state FROM aol.numbered n JOIN text_matches m USING(query_text)")
run("""CREATE OR REPLACE VIEW state_windows AS SELECT *,
 lag(has_state) OVER(PARTITION BY user_id,session_id ORDER BY search_ts,query_text) prev_has_state,
 lag(search_ts) OVER(PARTITION BY user_id,session_id ORDER BY search_ts,query_text) within_prev_ts,
 sum(has_state) OVER(PARTITION BY user_id,session_id ORDER BY search_ts,query_text ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) state_in_last3
 FROM session_flags""")
out('q5_sessions',"SELECT prev_has_state,count(*) eligible_transitions,sum(has_state) current_state_events,avg(has_state) current_state_share FROM state_windows WHERE within_prev_ts<search_ts GROUP BY prev_has_state ORDER BY prev_has_state")
out('session_context',"SELECT count(*) state_events,avg(state_in_last3) avg_state_events_last3,count(*) filter(where state_in_last3>=2) clustered_state_events FROM state_windows WHERE has_state=1")
out('session_totals',"SELECT count(*) sessions,sum(has_state) state_sessions FROM (SELECT user_id,session_id,max(has_state) has_state FROM session_flags GROUP BY user_id,session_id)")
# Exact-name and ambiguity sensitivity are descriptive comparisons, not deambiguation.
out('name_sensitivity',"SELECT state_name,count(*) primary_mentions,count(*) filter(where norm=lower(state_name)) exact_normalized_name_mentions,sum(source_rows) primary_source_rows FROM mentions GROUP BY state_name ORDER BY primary_mentions DESC")
no=d[~d.state_name.isin(['Georgia','Washington','New York'])]
f={'quality':q.iloc[0].to_dict(),'pearson_all50':float(d.population_2006.corr(d.mentions)), 'spearman_all50':float(d.population_2006.rank().corr(d.mentions.rank())), 'pearson_excluding_three':float(no.population_2006.corr(no.mentions)), 'spearman_excluding_three':float(no.population_2006.rank().corr(no.mentions.rank())), 'population_source':'https://www2.census.gov/programs-surveys/popest/datasets/2000-2006/state/totals/nst_est2006_alldata.csv'}
f['validation']={'states':len(d),'sum_mentions':int(d.mentions.sum()),'event_pair_unique':c.execute('SELECT count(*)=count(distinct(user_id,search_ts,query_text,state_fips)) FROM mentions').fetchone()[0],'cube_total':int(c.execute('SELECT count(*) FROM mentions').fetchone()[0]),'months':out('month_totals',"SELECT strftime(search_ts,'%Y-%m') search_month,count(*) mentions FROM mentions GROUP BY 1 ORDER BY 1").to_dict('records')}
(root/'results/facts.json').write_text(json.dumps(f,indent=2,default=int))
c.execute('CHECKPOINT');c.close();print(json.dumps(f,indent=2,default=int),flush=True)
