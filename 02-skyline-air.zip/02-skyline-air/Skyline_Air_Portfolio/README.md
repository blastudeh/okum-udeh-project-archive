# Skyline Air On-Time Performance Review

**Okum Udeh · Excel for Data Analytics capstone · Fictional airline case study**

I analysed flight records to understand punctuality patterns and identify practical operational priorities. I preserved the source data, documented cleaning decisions and built an Excel dashboard alongside native PivotTables and connected slicers.

![Native PivotTables and four slicers in Excel](evidence/native_pivots_excel.jpg)

## Results at a glance

| Measure | Result |
|---|---:|
| Source records | 1,012 |
| Exact duplicates removed | 12 |
| Unique flights | 1,000 |
| Arrival OTP | 703 / 957 = 73.46% |
| Departure OTP | 728 / 973 = 74.82% |
| Cancellations | 21 / 1,000 = 2.10% |
| First-half to second-half arrival OTP | 75.61% to 71.18% |

Period: 1 September 2025 to 31 August 2026. On time means less than 15 minutes late among eligible completed flights. Missing or inconsistent measures are excluded using documented rules. The monthly series fluctuates; these results do not establish a year-on-year decline.

## What I built

- [Excel workbook](deliverables/Skyline_Air_Analysis.xlsx): cleaned table, calculations, dashboard, two native PivotTables and four connected slicers.
- [Management report](deliverables/Skyline_Air_Report.docx) and [presentation](deliverables/Skyline_Air_Management_Presentation.pptx).
- [Detailed process record](docs/PROCESS.md), [Word copy](docs/Skyline_Air_Process_Record.docx) and [PDF copy](docs/Skyline_Air_Process_Record.pdf).
- [Exact helper formulas](docs/FORMULAS.md), CSV snapshots in data/, and [validation evidence](evidence/validation.json).
- [Captioned video walkthrough](media/Skyline_Air_Walkthrough.mp4) and [transcript](media/TRANSCRIPT.md).

## Process

1. Preserve the raw export and check record counts, types, identifiers and coverage.
2. Remove confirmed duplicate rows; standardise labels and retain a row-level cleaning history.
3. Sort whole flight rows from oldest to newest, then by scheduled time.
4. Define metric eligibility before calculating on-time rates and delay totals.
5. Compare monthly, airport, operating-time, aircraft and cause patterns with sample counts.
6. Build the dashboard and native PivotTables; connect four slicers to both native tables.
7. Reconcile totals, test filters and explain business recommendations with limitations.

## Main recommendation

Start with ATL aircraft rotations and later-day operations, then investigate JFK arrivals and SEA departures. Late Aircraft and Carrier labels are associated with 7,085 positive arrival-delay minutes. I would also improve cause completeness and time recording. These are investigation priorities, not proven root causes or guaranteed savings.

## Review the workbook

Open Native_Pivots in Excel to use the native slicers. Dashboard uses its own four drop-down filters, independently of these slicers. Clear filters to reproduce full-year results. Phone file previews may show blank slicer boxes; the included screenshot documents the controls rendered in Excel for the web.

Pivot_Analysis contains formula summaries. Native_Pivots was added after the copied management report and presentation were prepared; the process record documents that addition. The report and slides remain snapshots of the original results.

## Reproduce the checks

With Python and openpyxl installed, run `python scripts/validate_workbook.py` from this repository. The script reads the workbook without saving it. It checks duplicate reconciliation, date ordering, KPI counts, two PivotTable definitions, four slicer caches and cached error cells. It does not recalculate Excel or automate live clicks.

## Evidence and provenance

This is a retrospective portfolio record assembled from the completed project. The screenshot is an actual saved Excel view. The video is a silent, captioned presentation of the workflow and screenshot, not a recording of the original build or live filtering. The evidence documents the artifact and its checks; it does not claim a complete contemporaneous activity log. SHA256SUMS.txt identifies packaged files.

Skyline Air is fictional. Data is supplied capstone material, not a real client engagement. The original export is preserved in the workbook and as a CSV snapshot. The project does not include a Power Query cleaning pipeline. No public repository has been created or published as part of this package.
