from pathlib import Path
import duckdb
r=Path(__file__).resolve().parents[1]
c=duckdb.connect(str(r/'states.duckdb'),read_only=True)
c.execute("SELECT DISTINCT word FROM word_counts ORDER BY word").df().to_csv(r/'data/words.csv',index=False)
print('Exported vocabulary from terms meeting the publication thresholds.')
