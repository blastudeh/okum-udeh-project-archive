"""Create the minimal local source database from all ten archive TSVs."""
from pathlib import Path
import duckdb
r=Path(__file__).resolve().parents[1]
c=duckdb.connect(str(r/'aol_base.duckdb'))
c.execute("SET memory_limit='5GB'; SET threads=4; SET preserve_insertion_order=false")
c.execute("CREATE OR REPLACE TABLE raw AS SELECT * FROM read_csv('"+str(r/'raw/user-ct-test-collection-*.txt')+"',delim='\\t',header=true,all_varchar=true,quote='',escape='',null_padding=true,strict_mode=true)")
c.execute('''CREATE OR REPLACE TABLE events AS SELECT cast(AnonID AS BIGINT) user_id,
 cast(QueryTime AS TIMESTAMP) search_ts,"Query" query_text,count(*) source_rows,
 max(CASE WHEN try_cast(ItemRank AS INTEGER)>0 THEN 1 ELSE 0 END) has_click
 FROM raw WHERE try_cast(AnonID AS BIGINT) IS NOT NULL
 AND try_cast(QueryTime AS TIMESTAMP)>=TIMESTAMP '2006-03-01'
 AND try_cast(QueryTime AS TIMESTAMP)<TIMESTAMP '2006-06-01'
 AND "Query" IS NOT NULL AND trim("Query")<>'' AND trim("Query")<>'-'
 GROUP BY AnonID,QueryTime,"Query"''')
c.execute('''CREATE OR REPLACE TABLE numbered AS WITH ordered AS(
 SELECT *,lag(search_ts) OVER(PARTITION BY user_id ORDER BY search_ts,query_text) prev_ts
 FROM events)
 SELECT *,sum(CASE WHEN prev_ts IS NULL OR epoch(search_ts-prev_ts)>1800 THEN 1 ELSE 0 END)
 OVER(PARTITION BY user_id ORDER BY search_ts,query_text ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) session_id
 FROM ordered''')
assert c.execute('SELECT count(*) FROM raw').fetchone()[0]==36389567
assert c.execute('SELECT count(*) FROM events').fetchone()[0]==28037812
c.execute('CHECKPOINT');c.close();print('Base data prepared and checked.')
