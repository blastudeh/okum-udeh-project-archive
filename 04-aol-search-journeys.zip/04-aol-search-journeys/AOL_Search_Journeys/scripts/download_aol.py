import urllib.request,time,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
u='https://ndownloader.figshare.com/files/9570247'
(root/'raw').mkdir(parents=True,exist_ok=True)
p=root/'raw/aol-data.tar.bz2'
h=hashlib.md5(); total=0;last=time.time()
with urllib.request.urlopen(u,timeout=30) as r,p.open('wb') as f:
 while True:
  b=r.read(4*1024*1024)
  if not b:break
  f.write(b);h.update(b);total+=len(b)
  if time.time()-last>15:print('Downloaded',round(total/1e6,1),'MB',flush=True);last=time.time()
assert total==390571761,(total,'wrong file size')
assert h.hexdigest()=='6caf1d4dee151db0ddbdf08f8d171a55'
print('DOWNLOAD VERIFIED',total,h.hexdigest(),flush=True)
(root/'raw/source.json').write_text(json.dumps({'url':u,'landing':'https://figshare.com/articles/dataset/aol-data_tar_bz2/5527231','accessed':'2026-10-08','bytes':total,'md5':h.hexdigest()},indent=2))
