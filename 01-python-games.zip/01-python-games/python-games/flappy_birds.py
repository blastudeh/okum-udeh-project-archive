"""Flappy Birds: gravity, flap impulses, scrolling pipes and collision detection.
Run: python flappy_birds.py
"""
import random
import pygame
from common import run, text


class FlappyBirds:
    title = 'Flappy Birds'
    filename = 'flappy_birds'
    controls = 'Space / Up / mouse click: flap. Fly through the gaps between pipes.'
    GAP = 175
    SPEED = 175

    def __init__(self):
        self.y = 300.0
        self.velocity = 0.0
        self.started = False
        self.dead = False
        self.score = 0
        self.pipes = []
        self.timer = 0.0

    def key(self, key):
        if key in (pygame.K_SPACE, pygame.K_UP) and not self.dead:
            self.started = True
            self.velocity = -285.0

    def update(self, dt, keys, demo_frame=None):
        if demo_frame is not None and (not self.started or self.y > 310):
            self.key(pygame.K_SPACE)
        if not self.started or self.dead:
            return
        self.velocity += 650 * dt
        self.y += self.velocity * dt
        self.timer -= dt
        if self.timer <= 0:
            self.pipes.append({'x': 875.0, 'centre': random.randint(235, 370), 'passed': False})
            self.timer = 1.8
        for pipe in self.pipes:
            pipe['x'] -= self.SPEED * dt
            if not pipe['passed'] and pipe['x'] + 65 < 214:
                self.score += 1
                pipe['passed'] = True
            overlapping = 246 > pipe['x'] and 214 < pipe['x'] + 65
            outside_gap = self.y - 14 < pipe['centre'] - self.GAP / 2 or self.y + 14 > pipe['centre'] + self.GAP / 2
            if overlapping and outside_gap:
                self.dead = True
        self.pipes = [p for p in self.pipes if p['x'] > -65]
        if self.y - 14 < 95 or self.y + 14 > 505:
            self.dead = True

    def score_text(self):
        return f'Score: {self.score}'

    def message(self):
        if self.dead:
            return 'Game over! Press R to restart.'
        return 'Keep flying! Pass each pipe for one point.' if self.started else 'Press Space or click to start flying.'

    def draw(self, screen):
        pygame.draw.rect(screen, '#9cdae4', (25, 95, 850, 430), border_radius=12)
        screen.set_clip(pygame.Rect(25, 95, 850, 430))
        for x in (65, 350, 670):
            pygame.draw.ellipse(screen, '#f2faf0', (x, 140, 130, 35))
        for x in range(25, 880, 55):
            pygame.draw.rect(screen, '#b7d7c4', (x, 430 + x % 31, 40, 80))
        for pipe in self.pipes:
            x = int(pipe['x'])
            top = int(pipe['centre'] - self.GAP / 2)
            bottom = int(pipe['centre'] + self.GAP / 2)
            pygame.draw.rect(screen, '#338c65', (x, 95, 65, top - 95))
            pygame.draw.rect(screen, '#5dbd86', (x - 4, top - 18, 73, 18))
            pygame.draw.rect(screen, '#338c65', (x, bottom, 65, 505 - bottom))
            pygame.draw.rect(screen, '#5dbd86', (x - 4, bottom, 73, 18))
        pygame.draw.rect(screen, '#8eaf76', (25, 505, 850, 8))
        pygame.draw.rect(screen, '#cdbd8e', (25, 513, 850, 12))
        y = round(self.y)
        pygame.draw.ellipse(screen, '#ffd15c', (209, y - 16, 42, 32))
        pygame.draw.ellipse(screen, '#e8a13e', (207, y, 24, 12))
        pygame.draw.polygon(screen, '#e97842', [(246, y - 1), (263, y + 5), (246, y + 9)])
        pygame.draw.circle(screen, 'white', (239, y - 7), 8)
        pygame.draw.circle(screen, '#172633', (242, y - 7), 3)
        screen.set_clip(None)
        if self.dead or not self.started:
            pygame.draw.rect(screen, '#132330', (290, 265, 350, 60), border_radius=12)
            text(screen, 'Game over - press R' if self.dead else 'Press Space to fly', 330, 285, 30)


if __name__ == '__main__':
    run(FlappyBirds)
