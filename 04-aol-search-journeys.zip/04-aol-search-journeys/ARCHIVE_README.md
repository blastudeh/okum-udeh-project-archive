# AOL search journeys

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed local analysis; Exasol port unverified

Local DuckDB analysis of the 2006 AOL release, with aggregate reports, SQL, Python scripts and charts.

## Process

1. Download and extract the source according to bundled instructions.
2. Clean and deduplicate records.
3. Construct proxy search events and sessions.
4. Aggregate click, calendar, host and session statistics.
5. Document SQL port and methodological limits.

## Verification

Recovered completed package reports 36,389,567 raw records, 35,389,190 retained rows, 28,037,812 proxy events and 10,493,991 sessions. Large-data analysis was not rerun during archiving.

## Limits and provenance

This standalone DuckDB variant differs from the group Exasol pipeline. Its Exasol scripts were not executed in the supplied record. Raw search histories are not included; source data can contain sensitive historical searches. Aggregates do not establish intent or residence.
