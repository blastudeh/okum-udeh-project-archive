# Taxi Driver and Flappy Birds

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed playable implementations

Two Pygame games with source code, controls, rule tests and scripted demo screenshots.

## Process

1. Create a Python virtual environment and install requirements.txt.
2. Implement player movement, game state, collisions and scoring.
3. Run taxi_driver.py or flappy_birds.py.
4. Check game rules and capture scripted demonstrations.

## Verification

Reran all 5 bundled unit tests on 8 November 2026: PASS (Python 3.12, Pygame 2.6.1, dummy video/audio drivers).

## Limits and provenance

Bundled images are scripted headless renders, not photographs of the student’s Ubuntu desktop. These are playable games, not trained reinforcement-learning agents. No submission status is inferred.
