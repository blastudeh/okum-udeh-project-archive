CREATE TABLE AOL_STATES.THEMES (THEME VARCHAR(30), PATTERN VARCHAR(1000));
INSERT INTO AOL_STATES.THEMES VALUES ('Tourism','.*\b(hotel|hotels|vacation|vacations|beach|beaches|resort|resorts|tourism|tourist|tourists)\b.*');
INSERT INTO AOL_STATES.THEMES VALUES ('Education','.*\b(university|universities|college|colleges|school|schools)\b.*');
INSERT INTO AOL_STATES.THEMES VALUES ('Housing','.*\b(real estate|homes|housing|apartments|apartment|realtor|realtors)\b.*');
INSERT INTO AOL_STATES.THEMES VALUES ('Government','.*\b(tax|taxes|court|courts|dmv|license|licenses|government)\b.*');
CREATE VIEW AOL_STATES.THEME_HITS AS
SELECT m.*,t.THEME FROM AOL_STATES.MENTIONS m JOIN AOL_STATES.THEMES t
 ON m.NORM REGEXP_LIKE t.PATTERN;
