US STATE MENTIONS IN AOL SEARCH QUERIES
Corrected group topic - Okum Udeh, BHT Berlin - 8 October 2026

START HERE
This project analyzes state-name mentions, population normalization, associated
words, monthly comparisons, and session context. It does not infer residence.
All reported results were computed from the full AOL archive in DuckDB.
Exasol SQL is authored from official documentation but has not run in the course VM.

MAIN RESULTS
36,389,567 original rows; 28,037,812 cleaned proxy events.
1,132,545 events mention at least one state; 1,137,864 event-state pairs.
50-state population: 298,816,954 (Census vintage 2006).
Florida: 119,014 mentions; attention index 1.72773468088.
Delaware: 11,045 mentions; attention index 3.39851572838.
Pearson population/mention correlation: 0.809301423563 (50 states).
The approximate 67,000 Florida count in the group chat is not reconciled.

CONTENTS
scripts/ : executed analysis pipeline, chart scripts and validation.
data/ : original Census CSV, derived 50 states, dictionaries and vocabulary.
results/ : exact aggregate results and checks.
charts/ : six figures.
sql/ : Exasol scripts, ordered 01 through 06.
PROVENANCE.txt : sources, grain, scope and reuse notes.
SHA256_MANIFEST.json : file hashes of this package's components.
Raw AOL histories, user-level tables, databases and private chat screenshots
are intentionally excluded from the package.

REPRODUCE LOCAL ANALYSIS
Use Python 3.12 and install requirements.txt.
Allow ample memory and disk space for the source files, database and temp sorts.
The executed configuration uses DuckDB with memory_limit=5GB, threads=4.
Run from the extracted project folder:
  python -m pip install -r requirements.txt
  python scripts/download_aol.py
  python scripts/extract_aol.py
  python scripts/prepare_aol.py
  python scripts/analyze_states.py
  python scripts/export_vocabulary.py
  python scripts/validate_results.py
  python scripts/charts.py
The downloader verifies the published archive size and MD5.
prepare_aol.py creates aol_base.duckdb, which analyze_states.py prefers.
The script also supports the existing sibling aol_project/analysis.duckdb
from this conversation when no standalone base database exists.
Do not distribute the raw archive or derived user-level database in a class ZIP.

EXASOL / DATAGRIP
1. Run sql/01_tables.sql CREATE statements once in an authorized course schema.
2. Import all ten TSVs into RAW_LOG exactly once, using tabs, headers, UTF-8
   and no quoting. Import states_2006.csv into STATES with commas and header.
3. Run sql/02_prepare.sql and sql/03_themes.sql in order.
4. Run the five questions in sql/04_five_questions.sql.
5. Optional full word ranking: create WORDS using sql/05_common_words.sql,
   import data/words.csv, then execute its query. It can be expensive.
6. Run sql/06_validation.sql and reconcile differences before using VM results.
7. Capture actual query/results and table/schema screenshots for the appendix.
The scripts create AOL_STATES and do not alter the course's existing tables.
If you must use a granted schema, consistently change that qualifier throughout.
The raw archive field mapping is known. The course star schema is not yet mapped.

DEFINITIONS
Proxy event = user ID + exact timestamp + exact query text.
State matching = lowercase, non-ASCII-letter runs replaced with spaces,
full state-name boundaries, longest overlap, one pair per event and state.
No state abbreviations or ZIP inference. West Virginia does not count as Virginia.
Ambiguity remains (people, organizations, country/city names and similar text).
Index = state mention share / state population share, same 50-state universe.
Themes are non-exclusive keyword rules, not verified intent labels.
Word counts require >=100 matches and >=50 distinct anonymous IDs per state-word.
Session = within user, new after a gap strictly greater than 30 minutes.
Equal-time transitions are excluded from conditional state-event rates.
Bounded last-three windows retain deterministic lexical ordering for ties.

PACKAGE STATUS
Completed: actual local analysis, results, charts, documentation and Exasol scripts.
Pending: course VM execution, reconciliation and genuine screenshots.
