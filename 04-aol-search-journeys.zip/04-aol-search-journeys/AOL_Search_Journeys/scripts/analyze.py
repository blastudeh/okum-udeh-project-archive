from pathlib import Path
import duckdb,json,csv,time
root=Path(__file__).resolve().parents[1];out=root/'results';out.mkdir(exist_ok=True)
c=duckdb.connect(str(root/'analysis.duckdb'));c.execute("SET memory_limit='5GB'; SET threads=4; SET preserve_insertion_order=false;")
def run(s):
 t=time.time();c.execute(s);print('Completed',s.split('\n')[0][:85],round(time.time()-t,1),'s',flush=True)
def result(name,s):
 df=c.execute(s).df();df.to_csv(out/(name+'.csv'),index=False);return df
run("""CREATE OR REPLACE TABLE raw AS SELECT * FROM read_csv('"""+str(root/"raw/user-ct-test-collection-*.txt")+"""', delim='\\t', header=true, all_varchar=true, quote='', escape='', null_padding=true, strict_mode=true)""")
result('raw_quality',"""SELECT count(*) raw_rows, count(distinct AnonID) raw_users,
 min(QueryTime) first_timestamp,max(QueryTime) last_timestamp,
 count(*) filter(where "Query" is null or trim("Query")='') blank_queries,
 count(*) filter(where trim("Query")='-') dash_queries,
 count(*) filter(where try_cast(QueryTime AS TIMESTAMP) is null) bad_times,
 count(*) filter(where try_cast(AnonID AS BIGINT) is null) bad_users,
 count(*) filter(where try_cast(ItemRank AS INTEGER)>0) positive_rank_rows,
 count(*) filter(where ItemRank is not null and try_cast(ItemRank AS INTEGER) is null) invalid_rank_rows
 FROM raw""")
print((out/'raw_quality.csv').read_text(),flush=True)
run("""CREATE OR REPLACE TABLE events AS SELECT cast(AnonID AS BIGINT) user_id,
 cast(QueryTime AS TIMESTAMP) search_ts, "Query" query_text,
 max(CASE WHEN try_cast(ItemRank AS INTEGER)>0 THEN 1 ELSE 0 END) has_click,
 count(*) source_rows
 FROM raw WHERE try_cast(AnonID AS BIGINT) IS NOT NULL
 AND try_cast(QueryTime AS TIMESTAMP)>=TIMESTAMP '2006-03-01'
 AND try_cast(QueryTime AS TIMESTAMP)<TIMESTAMP '2006-06-01'
 AND "Query" IS NOT NULL AND trim("Query")<>'' AND trim("Query")<>'-'
 GROUP BY AnonID,QueryTime,"Query"
""")
result('event_quality',"""SELECT count(*) events,count(distinct user_id) users,
 sum(source_rows) retained_log_rows,sum(has_click) clicked_events,
 count(distinct query_text) distinct_texts,min(search_ts) start_ts,max(search_ts) end_ts
 FROM events""")
result('timestamp_ties',"""SELECT count(*) tied_user_timestamps,sum(n) events_in_ties FROM
 (SELECT user_id,search_ts,count(*) n FROM events GROUP BY user_id,search_ts HAVING count(*)>1)""")
run("""CREATE OR REPLACE TABLE ordered AS SELECT *,
 lag(search_ts) OVER (PARTITION BY user_id ORDER BY search_ts,query_text) prev_ts,
 lag(query_text) OVER (PARTITION BY user_id ORDER BY search_ts,query_text) prev_query
 FROM events""")
run("""CREATE OR REPLACE TABLE numbered AS SELECT *,
 sum(CASE WHEN prev_ts IS NULL OR epoch(search_ts-prev_ts)>1800 THEN 1 ELSE 0 END)
 OVER(PARTITION BY user_id ORDER BY search_ts,query_text ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) session_id
 FROM ordered""")
run("""CREATE OR REPLACE TABLE sessions AS SELECT user_id,session_id,count(*) searches,
 min(search_ts) start_ts,max(search_ts) end_ts,max(has_click) has_click,
 epoch(max(search_ts)-min(search_ts)) span_seconds
 FROM numbered GROUP BY user_id,session_id""")
result('session_summary',"""SELECT count(*) sessions,sum(searches) events,
 count(*) filter(where searches=1) single_event_sessions,
 sum(has_click) sessions_with_click,avg(searches) mean_searches,
 median(searches) median_searches,quantile_cont(searches,0.9) p90_searches,
 median(span_seconds) median_span_seconds FROM sessions""")
# External holiday table transcribed from NY Fed circular 11720 (2005).
holidays=[('2006-01-02',"New Year observance"),('2006-01-16','Martin Luther King Jr. Day'),('2006-02-20','Washington Birthday'),('2006-05-29','Memorial Day'),('2006-07-04','Independence Day'),('2006-09-04','Labor Day'),('2006-10-09','Columbus Day'),('2006-11-11','Veterans Day'),('2006-11-23','Thanksgiving'),('2006-12-25','Christmas')]
with (root/'holidays_2006.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['holiday_date','holiday_name']);w.writerows(holidays)
run("CREATE OR REPLACE TABLE holidays AS SELECT * FROM read_csv('"+str(root/'holidays_2006.csv')+"',header=true,types={'holiday_date':'DATE','holiday_name':'VARCHAR'})")
run("""CREATE OR REPLACE VIEW enriched AS SELECT e.*,cast(search_ts AS DATE) search_date,
 strftime(search_ts,'%Y-%m') search_month,extract(hour from search_ts) search_hour,
 extract(isodow from search_ts) weekday_no,
 CASE WHEN extract(isodow from search_ts)>=6 THEN 'Weekend' ELSE 'Weekday' END day_type,
 CASE WHEN h.holiday_date IS NOT NULL THEN 'Holiday' ELSE 'Ordinary day' END holiday_status,
 h.holiday_name
 FROM events e LEFT JOIN holidays h ON cast(e.search_ts AS DATE)=h.holiday_date""")
result('q1_cube',"""SELECT day_type,holiday_status,grouping(day_type) g_day,
 grouping(holiday_status) g_holiday,count(*) events,sum(has_click) clicked_events,
 count(distinct search_date) observed_days
 FROM enriched GROUP BY CUBE(day_type,holiday_status)""")
result('daily',"""SELECT search_date,weekday_no,day_type,holiday_status,count(*) events,
 sum(has_click) clicked_events,count(distinct user_id) users
 FROM enriched GROUP BY ALL ORDER BY search_date""")
result('hourly',"SELECT search_hour,count(*) events FROM enriched GROUP BY search_hour ORDER BY search_hour")
result('q2_rollup',"""WITH b AS(SELECT strftime(start_ts,'%Y-%m') start_month,
 CASE WHEN searches=1 THEN '1' WHEN searches<=3 THEN '2-3' WHEN searches<=6 THEN '4-6' ELSE '7+' END size_bin
 FROM sessions)
 SELECT start_month,size_bin,grouping(start_month) g_month,grouping(size_bin) g_bin,count(*) sessions
 FROM b GROUP BY ROLLUP(start_month,size_bin) ORDER BY start_month,size_bin""")
result('q3_grouping_sets',"""WITH b AS(SELECT CASE WHEN searches=1 THEN '1' WHEN searches<=3 THEN '2-3' WHEN searches<=6 THEN '4-6' ELSE '7+' END size_bin,
 CASE WHEN has_click=1 THEN 'Recorded click' ELSE 'No recorded click' END click_status FROM sessions)
 SELECT size_bin,click_status,grouping(size_bin) g_size,grouping(click_status) g_click,count(*) sessions
 FROM b GROUP BY GROUPING SETS((size_bin,click_status),(size_bin),()) ORDER BY size_bin,click_status""")
result('q4_refinement',"""WITH w AS(SELECT *,row_number() OVER(PARTITION BY user_id,session_id ORDER BY search_ts,query_text) step_no,
 sum(has_click) OVER(PARTITION BY user_id,session_id ORDER BY search_ts,query_text ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) recent_clicks
 FROM numbered)
 SELECT CASE WHEN step_no<=10 THEN cast(step_no AS VARCHAR) ELSE '11+' END step,
 count(*) events,
 count(*) filter(where prev_ts<search_ts AND epoch(search_ts-prev_ts)<=1800) ordered_transitions,
 count(*) filter(where prev_ts<search_ts AND epoch(search_ts-prev_ts)<=1800 AND query_text<>prev_query) changed_queries,
 avg(recent_clicks) avg_clicked_events_last3
 FROM w GROUP BY 1""")
# Rank hosts on retained source rows using the same period/text eligibility.
run("""CREATE OR REPLACE TABLE hosts AS SELECT strftime(cast(QueryTime AS TIMESTAMP),'%Y-%m') search_month,
 cast(AnonID AS BIGINT) user_id,
 regexp_extract(regexp_replace(regexp_replace(lower(trim(ClickURL)),'^[a-z]+://',''),'^www\\.',''),'^[^/:?#]+') host
 FROM raw WHERE try_cast(ItemRank AS INTEGER)>0 AND ClickURL IS NOT NULL
 AND try_cast(AnonID AS BIGINT) IS NOT NULL
 AND try_cast(QueryTime AS TIMESTAMP)>=TIMESTAMP '2006-03-01' AND try_cast(QueryTime AS TIMESTAMP)<TIMESTAMP '2006-06-01'
 AND "Query" IS NOT NULL AND trim("Query")<>'' AND trim("Query")<>'-'""")
result('q5_hosts',"""WITH a AS(SELECT search_month,host,count(*) click_rows,count(distinct user_id) users
 FROM hosts WHERE host<>'' GROUP BY search_month,host),r AS(SELECT *,dense_rank() OVER(PARTITION BY search_month ORDER BY users DESC) user_rank FROM a)
 SELECT * FROM r WHERE user_rank<=10 ORDER BY search_month,user_rank,host""")
result('hosts_overall',"SELECT host,count(*) click_rows,count(distinct user_id) users FROM hosts WHERE host<>'' GROUP BY host ORDER BY users DESC LIMIT 10")
# Reconstruct sessions at alternative thresholds and reconcile event count.
sens=[]
for seconds in [900,1800,3600]:
 df=c.execute(f"""WITH n AS(SELECT user_id,search_ts,has_click,
 sum(CASE WHEN prev_ts IS NULL OR epoch(search_ts-prev_ts)>{seconds} THEN 1 ELSE 0 END)
 OVER(PARTITION BY user_id ORDER BY search_ts,query_text ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) sid FROM ordered),
 s AS(SELECT user_id,sid,count(*) n,max(has_click) click FROM n GROUP BY user_id,sid)
 SELECT {seconds//60} threshold_minutes,count(*) sessions,sum(n) events,
 count(*) filter(where n=1) single_event_sessions,sum(click) sessions_with_click FROM s""").df();sens.append(df)
 print('Sensitivity',seconds,flush=True)
import pandas as pd
pd.concat(sens).to_csv(out/'session_sensitivity.csv',index=False)
result('exclusions',"""SELECT
 count(*) filter(where try_cast(QueryTime AS TIMESTAMP) IS NULL OR try_cast(AnonID AS BIGINT) IS NULL) invalid_key_rows,
 count(*) filter(where try_cast(QueryTime AS TIMESTAMP)<TIMESTAMP '2006-03-01' OR try_cast(QueryTime AS TIMESTAMP)>=TIMESTAMP '2006-06-01') outside_period_rows,
 count(*) filter(where "Query" IS NULL OR trim("Query")='' OR trim("Query")='-') no_usable_text_rows
 FROM raw""")
# SQL-native OLAP computation and validation totals, no raw histories in output.
assert c.execute('SELECT count(*) FROM raw').fetchone()[0]==36389567
assert c.execute('SELECT count(*) FROM events').fetchone()[0]==c.execute('SELECT sum(searches) FROM sessions').fetchone()[0]
for f in ['q1_cube','q2_rollup','q3_grouping_sets']:
 print(f,'exported',flush=True)
print('ANALYSIS COMPLETE',flush=True)
c.execute('CHECKPOINT')
c.close()
