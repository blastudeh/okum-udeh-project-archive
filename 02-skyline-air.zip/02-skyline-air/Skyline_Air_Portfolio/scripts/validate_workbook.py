"""Read-only structural checks; does not recalculate Excel or test live slicer clicks."""
from pathlib import Path
import json, zipfile, warnings, xml.etree.ElementTree as ET
import openpyxl
warnings.filterwarnings('ignore',category=UserWarning)
root=Path(__file__).resolve().parents[1]
p=root/'deliverables'/'Skyline_Air_Analysis.xlsx'
w=openpyxl.load_workbook(p,data_only=True)
rows=list(w['Cleaned_Data'].values)[1:]
rows=[r for r in rows if r[0]]
raw=[r for r in list(w['Raw_Data'].values)[1:] if r[0]]
keys=[(r[1],r[6],r[0]) for r in rows]
with zipfile.ZipFile(p) as z:
 pivots=[n for n in z.namelist() if n.startswith('xl/pivotTables/pivotTable') and n.endswith('.xml')]
 caches=[n for n in z.namelist() if n.startswith('xl/slicerCaches/slicerCache') and n.endswith('.xml')]
 connections={}
 for n in caches:
  e=ET.fromstring(z.read(n));connections[e.attrib.get('name',n)]=[t.attrib.get('name') for t in e.iter() if t.tag.split('}')[-1]=='pivotTable']
errors=[f'{s.title}!{c.coordinate}' for s in w for row in s for c in row if c.data_type=='e']
result={'raw_records':len(raw),'unique_raw_records':len(set(raw)), 'cleaned_records':len(rows),'unique_cleaned_ids':len(set(r[0] for r in rows)),'ascending_date_time_id':keys==sorted(keys),'arrival_eligible':sum(r[17] or 0 for r in rows),'arrival_on_time':sum(r[25] or 0 for r in rows),'departure_eligible':sum(r[16] or 0 for r in rows),'departure_on_time':sum(r[24] or 0 for r in rows),'native_pivot_count':len(pivots),'slicer_cache_count':len(caches),'slicer_connections':connections,'cached_excel_errors':errors}
assert result['raw_records']==1012 and result['unique_raw_records']==1000
assert result['cleaned_records']==result['unique_cleaned_ids']==1000
assert result['ascending_date_time_id']
assert [result[k] for k in ['arrival_eligible','arrival_on_time','departure_eligible','departure_on_time']]==[957,703,973,728]
assert len(pivots)==2 and len(caches)==4 and all(len(v)==2 for v in connections.values())
assert not errors
result['status']='PASS'
print(json.dumps(result,indent=2))
