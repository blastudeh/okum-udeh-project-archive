"""Taxi Driver: navigate roads, collect passengers and deliver three fares.
Run: python taxi_driver.py
"""
import math
import pygame
from common import run, text


class TaxiDriver:
    title = 'Taxi Driver'
    filename = 'taxi_driver'
    controls = 'Drive: arrow keys / WASD. Yellow P = pickup. Green D = destination.'
    stops = [(110, 170), (790, 170), (790, 450), (110, 450)]

    def __init__(self):
        self.x, self.y = 450.0, 450.0
        self.deliveries = 0
        self.carrying = False
        self.won = False

    @property
    def target(self):
        offset = 2 if self.carrying else 0
        return self.stops[(self.deliveries + offset) % 4]

    @staticmethod
    def road(x, y):
        """Keep the taxi centre far enough from the buildings and map edges."""
        return (50 < x < 850 and 115 < y < 505 and
                (any(abs(x - lane) < 24 for lane in (110, 450, 790)) or
                 any(abs(y - lane) < 24 for lane in (170, 310, 450))))

    def key(self, key):
        pass  # Driving uses held keys, handled in update().

    def update(self, dt, keys, demo_frame=None):
        if self.won:
            return
        dx = int(keys[pygame.K_RIGHT] or keys[pygame.K_d]) - int(keys[pygame.K_LEFT] or keys[pygame.K_a])
        dy = int(keys[pygame.K_DOWN] or keys[pygame.K_s]) - int(keys[pygame.K_UP] or keys[pygame.K_w])
        if demo_frame is not None:
            dx, dy = (-1, 0) if self.x > 111 else (0, -1)
        length = math.hypot(dx, dy) or 1
        x = self.x + dx / length * 190 * dt
        y = self.y + dy / length * 190 * dt
        if self.road(x, self.y):
            self.x = x
        if self.road(self.x, y):
            self.y = y
        if math.dist((self.x, self.y), self.target) < 25:
            if not self.carrying:
                self.carrying = True
            else:
                self.deliveries += 1
                self.carrying = False
                self.won = self.deliveries == 3

    def score_text(self):
        return f'Deliveries: {self.deliveries} / 3'

    def message(self):
        if self.won:
            return 'All passengers delivered! Press R to play again.'
        return 'Passenger aboard! Drive to D.' if self.carrying else 'Drive to P to collect the passenger.'

    def draw(self, screen):
        pygame.draw.rect(screen, '#a3bda5', (25, 95, 850, 430), border_radius=12)
        for y in (170, 310, 450):
            pygame.draw.rect(screen, '#3c505c', (45, y - 40, 810, 80))
            for x in range(50, 850, 32):
                pygame.draw.line(screen, '#99afb5', (x, y), (x + 15, y), 2)
        for x in (110, 450, 790):
            pygame.draw.rect(screen, '#3c505c', (x - 40, 115, 80, 390))
            for y in range(120, 500, 32):
                pygame.draw.line(screen, '#99afb5', (x, y), (x, y + 15), 2)
        for x in (175, 515):
            for y in (220, 360):
                pygame.draw.rect(screen, '#d4d5c4', (x, y, 210, 40), border_radius=5)
                for i in range(6):
                    pygame.draw.rect(screen, '#829e9f', (x + 12 + i * 32, y + 10, 17, 20))
        if not self.won:
            color = '#68e4af' if self.carrying else '#ffd15c'
            pygame.draw.circle(screen, color, self.target, 27)
            text(screen, 'D' if self.carrying else 'P', self.target[0] - 9, self.target[1] - 11, 30, '#172630')
        x, y = int(self.x), int(self.y)
        for ox in (-13, 7):
            for oy in (-19, 13):
                pygame.draw.rect(screen, '#15212b', (x + ox, y + oy, 8, 6))
        pygame.draw.rect(screen, '#ffd15c', (x - 20, y - 14, 40, 28), border_radius=5)
        pygame.draw.rect(screen, '#214253', (x - 8, y - 11, 16, 22), border_radius=3)


if __name__ == '__main__':
    run(TaxiDriver)
