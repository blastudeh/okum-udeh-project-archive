# AOL and GeoNames Exasol BI group project

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed analysis and reporting; separate later export documented

Group attribution: Michael, Okum and Phillip. SQL, geographic reference data, aggregate outputs and charts from the Exasol project. The November 3 question-3 report is retained as a separate result version.

## Process

1. Clean postal reference while retaining leading zeros.
2. Import reference data and build views over the existing AOL schema.
3. Run state, month, county, click and session analyses.
4. Compare cohort totals and sensitivity to extreme sessions.
5. Document the later question-3 export separately.

## Verification

Recovered handoff records actual DataGrip/Exasol execution by the student. This archival pass did not reconnect to the course database. The October ZIP cohort reports 18,697 events and 5,117 clicks (27.37%).

## Limits and provenance

Modern ZIP lookup does not identify users’ residences. October pipeline and November question-3 export have different populations and must not be combined. November report uses 1,190,929 events and summed state-user counts of 7,154, not globally distinct people. Star schema is a logical model; physical deployment and data-product canvas are not verified. Original desktop photos and user-level session exports are omitted.
