-- Exasol target schema. Run CREATE statements once.
-- These statements have been authored for Exasol, not executed in the VM.
CREATE SCHEMA AOL_JOURNEYS;
CREATE TABLE AOL_JOURNEYS.RAW_LOG (
 ANONID VARCHAR(100), "QUERY" VARCHAR(20000), QUERYTIME VARCHAR(100),
 ITEMRANK VARCHAR(100), CLICKURL VARCHAR(20000)
);
CREATE TABLE AOL_JOURNEYS.CALENDAR_2006 (
 SEARCH_DATE DATE, WEEKDAY_NO DECIMAL(1,0), DAY_TYPE VARCHAR(20),
 HOLIDAY_NAME VARCHAR(100), HOLIDAY_STATUS VARCHAR(20)
);
-- Import all ten user-ct-test-collection-XX.txt files into RAW_LOG.
-- Format: TAB separated, UTF-8, first row is header, no quote character.
-- Map AnonID -> ANONID, Query -> QUERY, QueryTime -> QUERYTIME,
-- ItemRank -> ITEMRANK, ClickURL -> CLICKURL.
-- Import calendar_2006.csv into CALENDAR_2006, comma separated, with header.
-- Do not import the files twice: an import into an existing table appends.
SELECT COUNT(*) AS RAW_ROWS FROM AOL_JOURNEYS.RAW_LOG;
-- Archive baseline: 36389567 rows.
SELECT COUNT(*) AS CALENDAR_DAYS, COUNT(DISTINCT SEARCH_DATE) AS UNIQUE_DATES
FROM AOL_JOURNEYS.CALENDAR_2006;
-- Expected: 92, 92.
