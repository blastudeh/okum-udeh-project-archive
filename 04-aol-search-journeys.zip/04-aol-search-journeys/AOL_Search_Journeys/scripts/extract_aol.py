import tarfile,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tarfile.open(root/'raw/aol-data.tar.bz2','r|bz2') as t:
 for m in t:
  if not m.isfile():continue
  name=Path(m.name).name
  if not name.endswith('.txt'):continue
  p=root/'raw'/name
  with t.extractfile(m) as src,p.open('wb') as dest:shutil.copyfileobj(src,dest,1024*1024)
  print(name,m.size,flush=True)
