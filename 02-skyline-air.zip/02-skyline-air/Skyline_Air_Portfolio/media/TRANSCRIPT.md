# Video transcript

Silent captioned walkthrough, 96 seconds. Assembled retrospectively; not an original screen recording.

## 00–12 seconds — Skyline Air performance review

Okum Udeh | Excel analytics capstone
A retrospective portfolio walkthrough
Fictional airline | September 2025 to August 2026

## 12–24 seconds — Preserve and inspect

1,012 source records and 13 original fields
Check identifiers, missing values and date coverage
Keep Raw_Data unchanged and retain SourceRow

## 24–36 seconds — Clean with a traceable record

Remove 12 exact duplicates: 1,000 unique flights
Standardise airports and recorded cause labels
Keep unknown causes separate from None recorded

## 36–48 seconds — Sort and validate

Sort complete rows by date, oldest to newest
Then sort by scheduled departure and FlightID
Retain early flights; flag conflicting measures

## 48–60 seconds — Define the denominator

Arrival: 703 on time / 957 eligible = 73.46%
Departure: 728 / 973 = 74.82%
21 cancellations reported separately

## 60–72 seconds — Actual Excel evidence

Two native PivotTables and four connected slicers
Saved Excel screenshot; this is not live footage

## 72–84 seconds — Interpret the findings

Arrival OTP: 75.61% first half to 71.18% second half
Monthly performance fluctuates
Prioritise ATL rotations and later-day operations

## 84–96 seconds — Check and hand over

Verify totals, ascending dates and slicer connections
Dashboard drop-downs are separate from native slicers
Full process, formulas and validation included

