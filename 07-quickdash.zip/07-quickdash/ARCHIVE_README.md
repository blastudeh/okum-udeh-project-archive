# QuickDash delivery performance

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed spreadsheet analysis

Delivery-fee analysis with a cleaned delivery sheet, analysis sheet and Lagos filter.

## Process

1. Clean duplicates and city labels.
2. Count deliveries independently of missing ratings.
3. Calculate fee totals, average, median and extremes.
4. Use Lagos filter and compare SUBTOTAL with whole-data SUM.
5. Write a management interpretation.

## Verification

Inspected saved workbook values: 109 deliveries, 95 ratings, total fees ₦380,640, average ₦3,492.11, median ₦3,740, Lagos fees ₦71,320.

## Limits and provenance

The original workbook contains named riders and payment-related delivery records. Only a documentation summary is archived here because the source’s synthetic/public status is unconfirmed; original workbook remains in ChatGPT. Cached results were inspected, not independently recalculated.
