from pathlib import Path
import json,re,pandas as pd,duckdb
r=Path(__file__).resolve().parents[1]
d=pd.read_csv(r/'results/state_summary.csv');q=pd.read_csv(r/'results/quality.csv').iloc[0]
cube=pd.read_csv(r/'results/q1_cube.csv');roll=pd.read_csv(r/'results/q3_rollup.csv')
checks={'fifty_states':len(d)==50 and d.state_name.nunique()==50,'population_sum':int(d.population_2006.sum())==298816954,'mention_sum':int(d.mentions.sum())==int(q.state_event_mentions),'mention_share_sum':abs(d.mention_share.sum()-1)<1e-12,'population_share_sum':abs(d.population_share.sum()-1)<1e-12,'index_recomputed':bool(((d.mentions/d.mentions.sum())/(d.population_2006/d.population_2006.sum())-d.attention_index).abs().max()<1e-12),'cube_total':int(cube[(cube.g_region==1)&(cube.g_state==1)].mentions.iloc[0])==int(q.state_event_mentions),'rollup_total':int(roll[(roll.g_month==1)&(roll.g_region==1)&(roll.g_state==1)].mentions.iloc[0])==int(q.state_event_mentions)}
pat=(r/'data/matching_pattern.txt').read_text();tests={'west virginia and florida hotels':{'west virginia','florida'},'virginia west virginia':{'virginia','west virginia'},'florida florida':{'florida'},'maineville':set(),'in ca or':set(),'new york and new jersey':{'new york','new jersey'}}
checks['boundary_examples']=all(set(re.findall(pat,t))==want for t,want in tests.items())
c=duckdb.connect(str(r/'states.duckdb'),read_only=True)
# Verify intended per-state matching logic against longest-name matching, all candidate texts.
checks['name_rule_equivalence']=c.execute("""WITH candidates AS(SELECT * FROM text_matches WHERE len(state_names)>0),
 alt AS(SELECT query_text,state_name FROM candidates CROSS JOIN states
 WHERE regexp_matches(CASE WHEN state_name='Virginia' THEN regexp_replace(norm,'\\bwest virginia\\b',' ','g') ELSE norm END,'\\b'||lower(state_name)||'\\b')),
 original AS(SELECT query_text,unnest(state_names) state_name FROM candidates)
SELECT count(*)=0 FROM ((SELECT query_text,lower(state_name) FROM alt EXCEPT SELECT * FROM original)
 UNION ALL (SELECT * FROM original EXCEPT SELECT query_text,lower(state_name) FROM alt))""").fetchone()[0]
checks['unique_event_state_pairs']=c.execute('SELECT count(*)=count(distinct(user_id,search_ts,query_text,state_fips)) FROM mentions').fetchone()[0]
c.close()
t=pd.read_csv(r/'results/common_words.csv');checks['term_thresholds']=bool((t.mentions>=100).all() and (t.users>=50).all())
z=pd.read_csv(r/'results/q5_sessions.csv');checks['session_rates']=bool(((z.current_state_events/z.eligible_transitions)-z.current_state_share).abs().max()<1e-12)
checks={k:bool(v) for k,v in checks.items()}
assert all(checks.values()),checks
(r/'results/validation.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
