"""Focused tests for game rules; no graphical window needed."""
import unittest
from collections import defaultdict
import pygame
from taxi_driver import TaxiDriver
from flappy_birds import FlappyBirds


class GameTests(unittest.TestCase):
    def test_taxi_three_deliveries(self):
        g = TaxiDriver()
        for _ in range(3):
            g.x, g.y = g.target
            g.update(0, defaultdict(bool))
            self.assertTrue(g.carrying)
            g.x, g.y = g.target
            g.update(0, defaultdict(bool))
        self.assertTrue(g.won)
        self.assertEqual(g.deliveries, 3)

    def test_taxi_building_blocks_movement(self):
        g = TaxiDriver()
        g.x, g.y = 133, 240
        g.update(.04, defaultdict(bool, {pygame.K_RIGHT: True}))
        self.assertEqual(g.x, 133)

    def test_flap_and_ground_collision(self):
        g = FlappyBirds()
        g.key(pygame.K_SPACE)
        self.assertLess(g.velocity, 0)
        g.y = 510
        g.update(0, {})
        self.assertTrue(g.dead)

    def test_pipe_collision(self):
        g = FlappyBirds()
        g.started = True
        g.y = 150
        g.pipes = [{'x': 230, 'centre': 300, 'passed': False}]
        g.update(0, {})
        self.assertTrue(g.dead)

    def test_score_once_in_safe_gap(self):
        g = FlappyBirds()
        g.started = True
        g.y = 300
        g.pipes = [{'x': 140, 'centre': 300, 'passed': False}]
        g.update(0, {})
        g.update(0, {})
        self.assertEqual(g.score, 1)
        self.assertFalse(g.dead)


if __name__ == '__main__':
    unittest.main()
