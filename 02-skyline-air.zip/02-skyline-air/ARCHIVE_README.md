# Skyline Air flight performance

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed Excel capstone

Fictional-airline analysis of 1,012 raw records, 12 exact duplicates and 1,000 unique flights. Arrival OTP: 703/957 (73.46%); departure OTP: 728/973 (74.82%).

## Process

1. Preserve raw records and document cleaning.
2. Remove exact duplicates and sort whole records.
3. Define eligibility and calculate punctuality metrics.
4. Build dashboard, two native PivotTables and four connected slicers.
5. Prepare management report, slides and process record.

## Verification

Reran supplied read-only validator on 8 November 2026: PASS. It checks counts, ordering, KPI reconciliation, 2 PivotTables, 4 slicer caches and no cached Excel errors.

## Limits and provenance

Validator does not recalculate Excel or exercise live slicer clicks. Dashboard dropdowns are separate from Native_Pivots slicers. Original video is a captioned reconstruction, not a contemporaneous build recording. Source case is fictional. Original documents remain historical snapshots.
