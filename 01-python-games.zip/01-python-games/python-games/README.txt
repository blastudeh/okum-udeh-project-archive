EXERCISE 1 - TAXI DRIVER & FLAPPY BIRDS (PYTHON)

1. Extract this ZIP and open the extracted python-games folder in VS Code.
2. Open Terminal > New Terminal. On Ubuntu run:

   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements.txt

   If Ubuntu reports that venv is missing, install it:
   sudo apt install python3-venv
   Then repeat the commands above.

3. Run Taxi Driver:
   python taxi_driver.py

4. Close its window, then run Flappy Birds:
   python flappy_birds.py

Taxi: use arrows or WASD. Drive to yellow P, then green D. Deliver 3 fares.
Flappy: press Space, Up, or click to flap. Avoid pipes, floor and ceiling.
Both: R restarts, P pauses, Esc closes, F12 saves a PNG into screenshots/.
Click the game window first so it receives keyboard input.

On Windows, use `py -m venv .venv` then `.venv\Scripts\activate`.
The remaining python commands are the same.

SCREENSHOTS FOR SUBMISSION
Run each game, play briefly, press F12. Upload the two PNG files from
screenshots/ to your course assignment. You can also use Ubuntu's Screenshot
application if your lecturer wants the desktop or VS Code visible.
The bundled PNGs are genuine Pygame renderings from scripted demo runs in a
headless display; create your own screenshots locally if that is required.
No submission has been made to the course portal.

FILES
common.py: shared event loop, window, pause/restart and screenshot saving.
taxi_driver.py: movement, road boundaries, passenger pickup and delivery.
flappy_birds.py: gravity, jumping, pipes, score and collision detection.
test_games.py: tests for delivery, blocked movement, collisions and scoring.
requirements.txt: the one external dependency, Pygame.

No external images, fonts, audio or internet connection are needed after setup.
Python 3.10 or newer recommended. Run in a normal Ubuntu desktop terminal.
Docker/dev containers may not have graphical display access; use your Ubuntu
VM desktop terminal outside the container if no window appears.

Validation:
   python -m unittest -v test_games.py
Demo screenshots:
   python taxi_driver.py --demo-screenshot
   python flappy_birds.py --demo-screenshot

These are playable Python games, not reinforcement-learning agents or Gymnasium
environments. The provided assignment text did not specify those requirements.
