US POSTAL CODES
41490 source rows; 12 original fields. No rows removed.
Source: GeoNames https://www.geonames.org/ (see original readme in supplied ZIP).

EXCEL: Open US_Postal_Codes.xlsx. Filter using the header arrows.
MYSQL: Open Workbench, connect to your server, choose File > Open SQL Script, and open US_Postal_Codes_MySQL.sql. Run the full script with the lightning bolt. It creates us_geography.us_postal_codes. Run only once. If the table already exists, stop rather than rerunning the inserts.
Requires CREATE DATABASE and CREATE TABLE privileges. Your existing databases are not deleted.
The CSV is an alternative import format. Use text types for postal and administrative codes to preserve leading zeros.

Fields: country_code; postal_code; place_name; state_name; state_code; county_name; county_code; community_name; community_code; latitude; longitude; accuracy.
Coordinates are estimates as described by the source. Accuracy is the source code (1=estimated, 4=geonameid, 6=centroid). Empty text fields stay empty; empty numeric fields become NULL.
record_id is added only in MySQL to identify each source row. Postal code alone is not assumed unique.
