-- Extra Q4 query: exact token counting. Derive WORDS in Python, import vocabulary only.
-- scripts/export_vocabulary.py writes data/words.csv. No user IDs or full queries included.
CREATE TABLE AOL_STATES.WORDS (WORD VARCHAR(20000));
-- Import words.csv here before running the next statement.
-- This join can be expensive. Materialize or use a course-approved tokenizer if needed.
WITH counts AS (
 SELECT m.STATE_NAME,w.WORD,COUNT(*) AS MENTIONS,COUNT(DISTINCT m.USER_ID) AS USERS
 FROM AOL_STATES.MENTIONS m JOIN AOL_STATES.WORDS w
 ON m.NORM REGEXP_LIKE ('.*\b'||w.WORD||'\b.*')
 GROUP BY m.STATE_NAME,w.WORD
 HAVING COUNT(*)>=100 AND COUNT(DISTINCT m.USER_ID)>=50
), ranks AS (
 SELECT counts.*,DENSE_RANK() OVER(PARTITION BY STATE_NAME ORDER BY MENTIONS DESC) AS WORD_RANK
 FROM counts
) SELECT * FROM ranks WHERE WORD_RANK<=10 ORDER BY STATE_NAME,WORD_RANK,WORD;
