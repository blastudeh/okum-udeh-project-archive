# Bright Path recruitment data quality

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed workbook; documentation-only archive

Spreadsheet cleaning and data-quality exercise involving 110 application records.

## Process

1. Preserve raw records and source-row lineage.
2. Standardize text and validate identifiers.
3. Map branch codes and flag missing scores.
4. Document duplicates and assumptions.
5. Produce a summary with limitations.

## Verification

Inspected workbook sheets: Summary, Cleaned Candidates, Raw Data, BranchLookup and Data Quality Log. Summary records 18 missing interview scores, 2 malformed IDs and 4 excess exact copies.

## Limits and provenance

Candidate records, contact details and screening outputs are not uploaded. The original workbook remains in ChatGPT. No new selection or employment decision was made. Record counts are not verified unique-person counts; assumed score ranges require confirmation.
