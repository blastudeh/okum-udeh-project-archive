# US postal data for Excel and MySQL

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed conversion; database import unverified

A 41,490-row, 12-field GeoNames export converted to Excel, CSV and a MySQL creation/import script.

## Process

1. Retain original rows and reference attribution.
2. Preserve postal/admin codes as text.
3. Export CSV and filterable Excel table.
4. Generate MySQL schema and inserts with numeric NULL handling.

## Verification

Recovered package includes all three formats and original GeoNames readme. No successful MySQL execution is claimed.

## Limits and provenance

This source preserves duplicate ZIP codes; postal code alone is not a unique key. It differs from the 40,977-row cleaned lookup used in the Exasol project. Read READ_ME.txt before import; do not repeat inserts blindly.
