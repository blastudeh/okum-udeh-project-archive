# Skyline Air project process record

Prepared by Okum Udeh

## Project purpose and evidence

I reviewed a fictional airline’s flight records to understand its on-time performance and identify where an operational investigation would be most useful. My project combines a cleaned dataset, an Excel dashboard, native PivotTables and slicers, a management report and a presentation.

The source export contains 1,012 records covering 1 September 2025 to 31 August 2026. After removing 12 exact duplicates, the analysis contains 1,000 unique flights. Arrival on-time performance is 73.46% across 957 eligible flights. The second half is weaker than the first, but monthly results fluctuate.

This portfolio records the completed workflow and provides evidence that can be inspected. It is a retrospective process record, not a timestamped recording of every original action. The Excel screenshot is from the completed workbook. The included video is a captioned walkthrough assembled for this portfolio.

Project owner: Okum Udeh. Context: Month 1 Excel for Data Analytics capstone. Skyline Air and its operational data are fictional; this is not evidence of employment or a real airline engagement.

The workbook is the primary calculation evidence. Raw_Data preserves the original rows, Cleaned_Data contains the processed table, Cleaning_Log traces decisions, and Definitions explains the calculation rules. The copied report and presentation are management snapshots. This guide documents the later addition of native PivotTables and slicers.

## Step 1 Preserve and inspect the data

I kept an unchanged copy of the export in Raw_Data before preparing the cleaned table. I checked the number of records, the 13 source fields, the date range, identifiers, flight statuses, missing values and label consistency. I compared full source rows to identify exact duplicates, rather than deleting every repeated identifier without checking its contents.

I removed the later copy of each of the 12 exact duplicates and retained the first. Cleaning_Log identifies each removed source row and its retained counterpart. The reconciliation is 1,012 raw records minus 12 duplicates equals 1,000 unique flights. No conflicting FlightIDs remain.

I retained a SourceRow field in Cleaned_Data so a flight can be traced to its original Excel row. For example, the first cleaned flight, SK-00001, points to source row 2. This makes a correction reviewable without relying on memory.

The dates and times were already native Excel values, and numeric fields did not require text conversion. I applied the date display dd-mmm-yyyy and sorted complete rows by FlightDate ascending, then ScheduledDeparture and FlightID. Sorting complete rows preserved the relationship between each flight and its values.

Evidence to inspect: Raw_Data, Cleaned_Data columns A:N, and the removed-record section in Cleaning_Log. The CSV copies in data/ make these records inspectable without Excel; they do not preserve Excel formulas or formatting.

## Step 2 Clean labels and resolve quality issues

I standardised 120 origin labels, 56 destination labels and 101 delay-cause synonyms. Examples include lower-case airport codes, extra spaces, WX to Weather, Carrier Delay to Carrier and LateAircraft to Late Aircraft. City aliases were mapped to the codes represented in this dataset. New York to JFK, Chicago to ORD and Dallas to DFW remain assumptions to confirm with a source owner.

I kept 143 missing causes as Unknown and kept 590 literal None labels as None recorded. Those categories are different: a missing or uninformative cause does not establish that a flight had no delay. There were 38 delayed arrivals carrying None recorded.

I retained plausible negative delays, since early flights are valid. The log records 401 flights with negative delays retained. I used -60 to 1,440 minutes as a review screen, not as an industry standard or an automatic correction rule.

Six departure values conflicted with scheduled and actual clock times after a modulo-24-hour check. Five extreme departure values fall within those six cases. I preserved the recorded values and excluded these flights from departure metrics. I did not assume a next-day departure date or replace the delay.

Twenty-two completed flights had missing arrival delays and were excluded only from arrival metrics. Twenty-two had missing actual departure times; a separately usable departure-delay value remained eligible. Four nonpositive distances were retained and flagged because distance was not used in punctuality calculations.

A total of 227 unique flights had review flags. Issue categories overlap, so their counts must not be added together. Cancelled flights remained in total-flight and cancellation counts. Their blank flight measures were not replaced with zeros.

## Step 3 Define and calculate performance

I defined on time as a delay below 15 minutes among eligible completed flights. Exactly 15 minutes counts as delayed. Arrival eligibility requires a numeric arrival delay within the review range; departure eligibility also excludes time conflicts. These rules are recorded in Definitions and the helper formulas.

The dataset has 979 completed flights and 21 cancellations, with no diverted flights. Arrival eligibility is 979 minus 22 missing outcomes, or 957. Departure eligibility is 979 minus six conflicts, or 973. Arrival OTP is 703 / 957 = 73.46%; departure OTP is 728 / 973 = 74.82%. Cancellation rate is 21 / 1,000 = 2.10%.

I used DATE, YEAR, MONTH and TEXT to create month fields; WEEKDAY with Monday as day 1 for weekday order; and HOUR for scheduled departure bands. Bands are night 00:00–05:59, morning 06:00–11:59, afternoon 12:00–17:59 and evening 18:00–23:59. The source timezone is unspecified.

IF, AND, OR and ISNUMBER implement eligibility and quality checks. MAX(delay,0) creates positive-delay totals. SUM, SUMIFS and COUNTIFS support the summaries. Average delay includes valid negative values; delayed-only means use delays of at least 15 minutes. Arrival and departure minutes are kept separate.

I calculated total percentages from summed counts rather than averaging percentages across months or airports. The workbook contains 14,235 positive arrival-delay minutes and 14,990 positive departure-delay minutes. The formula catalogue in docs/ contains the exact helper formulas from the delivered workbook.

Formula-based Dashboard controls use the Selected helper. The four blue drop-downs select month, origin, destination and aircraft. Static findings are labelled separately. This project does not contain a saved Power Query cleaning pipeline.

## Step 4 Build native PivotTables and slicers

The completed workbook contains both formula summaries on Pivot_Analysis and real Excel PivotTables on Native_Pivots. I used the FlightsClean table as the source. For the monthly PivotTable, MonthName is the row field and ArrivalEligible and ArrivalOnTime are summed values. MonthName uses yyyy-mm, so ascending order is chronological across the year boundary.

For the airport PivotTable, Origin is the row field and DepartureEligible and DepartureOnTime are summed values. I set the aggregation to Sum rather than Count; counting nonblank flag cells would give an incorrect on-time numerator.

The OTP percentages sit beside the PivotTables and divide on-time counts by eligible counts. They are worksheet formulas rather than a native calculated PivotTable field. The monthly result occupies A3:D16 and the airport result F3:I16 in the saved all-flight view.

I added MonthName, Origin, Destination and AircraftType slicers and connected every slicer to both native PivotTables. These slicers control the two tables on Native_Pivots. The Dashboard has separate drop-down filters; changing a native slicer does not change the Dashboard.

To reproduce the setup in Excel, select FlightsClean, insert a PivotTable, place the stated fields into Rows and Values, and set each value to Sum. Create the second table from the same source, insert the four slicers, and use PivotTable Connections or Report Connections to select both tables. Menu wording can vary by Excel edition.

I used navy headings, pale blue inputs, teal calculation accents, amber review flags, red delays or errors and green favourable results. A legend explains the colours. The saved screenshot shows the native controls inside Excel for the web; the phone file preview previously displayed slicers as empty boxes.

## Step 5 Analyse patterns and form recommendations

I compared months, origin departures, destination arrivals, weekdays, scheduled departure bands, aircraft types and recorded causes. I paired rates with flight counts and used a caution convention for fewer than 30 eligible observations.

Arrival OTP was 372 / 492 = 75.61% in the first six months and 331 / 465 = 71.18% in the second six months, a decrease of 4.43 percentage points. October was strongest at 85 / 100 = 85.0%; May was weakest at 49 / 78 = 62.82%. This demonstrates a weaker second half, not a steady monthly or year-on-year decline.

ATL recorded 50 delayed departures from 158 eligible flights. Its later-day pattern makes aircraft rotations and turnaround activity a practical investigation priority. SEA had the highest departure-delay rate, while JFK had the weakest arrival OTP. I would review routes, volumes and timing before assigning responsibility to an airport.

Late Aircraft and Carrier labels were associated with 7,085 positive arrival-delay minutes. I treated Carrier as potentially controllable, Late Aircraft and Security as partly controllable, and Weather and ATC as largely external. One cause label per flight does not prove that it caused every recorded minute.

My recommendations are to review ATL turnarounds and rotations, investigate JFK arrivals and SEA departures, improve cause and time recording, and strengthen disruption recovery. I would monitor eligible-flight OTP, positive delay minutes, cancellation rate and missing-data rates. I did not invent savings or promise an improvement.

The aircraft and timing comparisons show associations. Route mix, schedules and operating conditions could explain some differences. More than one year of data, actual departure dates and turnaround milestones would be needed for stronger diagnosis.

## Step 6 Validate and preserve the evidence

I reconciled the raw and cleaned totals and checked that the 1,000 cleaned flights are ordered by date and scheduled departure. I verified the saved all-flight native totals: 957 eligible arrivals and 703 on time; 973 eligible departures and 728 on time.

The earlier Excel interaction checks included filtering MonthName to October 2025: the monthly table showed 100 eligible arrivals and 85 on time, while the airport departure total showed 101 eligible departures and 86 on time. Filtering Origin to ATL showed 153 eligible arrivals and 97 on time, with 158 eligible departures and 108 on time. Filters were cleared before the final export.

The saved XLSX package contains two native PivotTable definitions and four slicer caches. Every slicer cache references both PivotTables. I also checked cached cell errors and preserved the original workbook binary when making this portfolio copy, so copying would not strip native Excel features.

The evidence directory contains the actual Excel screenshot and a new machine-readable validation result. scripts/validate_workbook.py repeats the structural, sorting and count checks without changing the workbook. This script does not run Excel or test live clicks; the recorded interaction results above describe the earlier Excel tests.

The process guide, video and README were assembled after completion. There is no invented commit history or claim that the video shows all original actions. The included hashes identify the exact packaged files; they establish file identity, not who performed an action or when it originally occurred.

The copied report and presentation retain their earlier management narrative. Where they describe formula summaries, that remains true of Pivot_Analysis; Native_Pivots was added later. This process guide records that later feature addition explicitly.

## Step 7 Showcase and maintain the project

For a portfolio repository, I would use the included README as the landing page, keep the workbook, report and presentation in deliverables/, and include docs/, evidence/, data/, media/ and scripts/ so reviewers can follow the work. The ZIP preserves this structure. No public upload has been made by preparing this package.

A reviewer can begin with the README, inspect the Excel screenshot, open the workbook on Native_Pivots and test a slicer, then trace a flight through SourceRow and Cleaning_Log. Dashboard results should be reviewed separately using its blue drop-downs. The captioned MP4 gives a short overview; its transcript is included for accessibility and reuse.

For a fresh live demonstration, start with all filters cleared. Show Raw_Data and Cleaning_Log, display ascending dates in Cleaned_Data, explain the eligibility fields, then open Native_Pivots. Select October 2025 and verify 100 / 85 arrivals and 101 / 86 departures. Clear that filter, select ATL, verify 153 / 97 arrivals and 158 / 108 departures, and clear all filters again.

When adding data, extend FlightsClean, fill the helper formulas, repeat the cleaning checks and sort whole rows. Add any new categories to summaries, chart ranges and filter choices. Refresh both native PivotTables in Excel, allow workbook calculations to finish and reconcile counts. The adjacent OTP output ranges currently end at row 16, so expand them if the PivotTable gains rows.

The report, slides, screenshot and video are snapshots and must be regenerated when the underlying results change. The recorded Cleaning_Log remains a history of the original preparation; append new decisions when cleaning a later export.

Suggested portfolio description: I analysed 1,000 fictional airline flight records in Excel, documented data-quality decisions, built a dashboard and native PivotTables with four connected slicers, and translated delay patterns into operational recommendations. My focus was traceability, correct KPI denominators and clear communication.

