/* OKUM'S ASSIGNED QUESTION — EXASOL
How do search interests differ across US states and evolve over time?
Source: Star-Schema FigJam board exported 4 Nov 2026; not a live DB read.
STATUS: prepared SQL, not executed against your Exasol database.
Run each numbered statement separately in DataGrip. Run SECTION A first.
All statements are read-only: no original tables are altered.

IMPORTANT BEFORE SECTION B:
1. Confirm actual columns using A1. These names match the board, not a live DB.
2. Inspect month and category encodings in A2/A3.
3. TRUE FIRST CLICK requires a reliable click timestamp/sequence. IRANK is
   result position, not chronological click order. Section B uses the lowest
   numeric result rank as a PROVISIONAL proxy. Do not call it 'first click'.
   Agree this fallback with the group/lecturer OR replace its ranking order
   with a verified click sequence. Do not order by URLID as proof of time.
4. A query event is (ANONID, QUERYID, TIMEID), provisionally. Validate that
   TIMEID represents query submission time and identifies repeated searches.
   QUERYID alone can be shared by different users/times.
5. TOPIC_1/TOPIC_2 mapping below must match A3. 'Top' is a root, not a topic.

METHODOLOGY
- Rebuild user ZIP assignment from the board's regex and valid ZIPs.
- Reject users associated with multiple valid ZIPs. Assign remaining users'
  location to ALL their search events, not only queries containing a ZIP.
- Deduplicate ZIP/state mappings; reject ambiguous state mappings.
- Restrict primary comparison to 50 US states (DC/territories excluded).
- Select one clicked URL BEFORE joining URL_CATEGORY.
- Keep all category IDs at join, then deduplicate broad topic membership
  within each event. Two subcategories of Arts count as Arts once.
- Keep unmatched chosen URLs as [Unclassified]. Never substitute a later
  matched click for an unmatched selected click.
- For k broad topics, each receives 1/k of the event: weighted shares sum
  to 100% including Unclassified. Membership percentages can exceed 100%
  when added across topics; do not use those for 100% stacked bars.
- This is search-event weighted, not equal-user weighted. Heavy searchers
  still matter. A one-URL rule removes multiple-click inflation only.
- Location is inferred from typed ZIP codes, not verified residence.
- No population denominator is necessary for within-state topic shares.
- Show sample sizes and DMOZ coverage. Do not generalize to all residents.
- Historical cohort uses evidence from the whole log period. Do not present
  it as a location that was known at each historical date.

DOCUMENTATION / AI USE
AI reviewed the provided board and drafted this SQL and methodology.
The analyst must run it, verify outputs, record edits and interpret results.
No real query results or regional/time conclusions have been generated here.
Record: date, query section, error message, cause, fix and re-run result.
Known board issue: FINAL joins LOCATIONDIM via each query's extracted ZIP;
this loses location for other queries made by an already-located user.
Other risks: duplicate ZIP/place rows, multi-category expansion, string ranks,
small state samples, missing categories, false ZIP matches, partial months.

References:
https://www.figma.com/board/rxsrf9RFdm4ru2ERzYkRCH/Star-Schema
https://docs.exasol.com/db/7.1/sql/select.htm
https://docs.exasol.com/db/latest/sql_references/functions/alphabeticallistfunctions/grouping%5B_id%5D.htm
https://docs.exasol.com/db/latest/sql_references/predicates/not_regexp_like.htm
*/

-- SECTION A: SEND THESE RESULTS FIRST; DO NOT RUN THE WHOLE FILE AT ONCE.
-- A1. Confirm columns and whether click order fields exist.
SELECT COLUMN_TABLE, COLUMN_NAME, COLUMN_TYPE
FROM EXA_ALL_COLUMNS
WHERE COLUMN_SCHEMA = 'AOL_SCHEMA'
  AND COLUMN_TABLE IN ('FACTS','QUERYDIM','TIMEDIM','LOCATIONDIM',
                       'URLDIM','URL_CATEGORY','DMOZ_CATEGORIES','ANONIDDIM')
ORDER BY COLUMN_TABLE, COLUMN_ORDINAL_POSITION;

-- A2. Actual year/month labels and day coverage in the time dimension.
-- This does NOT alone establish coverage of the final analysis cohort.
SELECT "YEAR", "MONTH", MIN(DAY_OF_THE_MONTH) AS FIRST_DAY_TEXT,
       MAX(DAY_OF_THE_MONTH) AS LAST_DAY_TEXT, COUNT(*) AS TIME_ROWS
FROM AOL_SCHEMA.TIMEDIM
GROUP BY "YEAR", "MONTH"
ORDER BY "YEAR", "MONTH";

-- A3. Confirm DMOZ hierarchy (e.g. TOPIC_1='Arts', or 'Top' then 'Arts').
SELECT TOPIC, TITLE, TOPIC_1, TOPIC_2, TOPIC_3
FROM AOL_SCHEMA.DMOZ_CATEGORIES
ORDER BY CATID
LIMIT 30;

-- A4. Are clicks indicated as expected? Is rank a clean numeric string?
SELECT CLICK, IRANK, COUNT(*) AS N_ROWS
FROM AOL_SCHEMA.FACTS
GROUP BY CLICK, IRANK
ORDER BY N_ROWS DESC
LIMIT 30;

-- A5. Geography sample: leading zero ZIPs, state codes, duplicate places.
SELECT POSTAL_CODE, STATE_NAME, STATE_CODE, COUNT(*) AS LOCATION_ROWS
FROM AOL_SCHEMA.LOCATIONDIM
GROUP BY POSTAL_CODE, STATE_NAME, STATE_CODE
ORDER BY LOCATION_ROWS DESC
LIMIT 30;

/* SECTION B: MAIN PROVISIONAL ANALYSIS
Run only after inspecting Section A and resolving the first-click definition.
Uses Exasol REGEXP_LIKE as a predicate, not a two-argument function.
ROW_NUMBER ranking happens BEFORE category joins.
MONTH accepts numeric values or English month names. Invalid dates/months
must be investigated; they are not silently converted to another month.
No hardcoded March-June assumption: output uses observed source months.
*/
WITH
ZIP_STATE AS (
    SELECT LPAD(TRIM(CAST(POSTAL_CODE AS VARCHAR(10))),5,'0') AS ZIP_CODE,
           MIN(STATE_CODE) AS STATE_CODE,
           MIN(STATE_NAME) AS STATE_NAME
    FROM AOL_SCHEMA.LOCATIONDIM
    WHERE TRIM(CAST(POSTAL_CODE AS VARCHAR(10))) REGEXP_LIKE '^[0-9]{1,5}$'
      AND STATE_CODE IS NOT NULL
    GROUP BY LPAD(TRIM(CAST(POSTAL_CODE AS VARCHAR(10))),5,'0')
    HAVING COUNT(DISTINCT STATE_CODE)=1
),
QUERY_ZIP AS (
    SELECT ID AS QUERYID,
           REGEXP_SUBSTR("QUERY",'(?<![A-Za-z0-9_#])[0-9]{5}(?![A-Za-z0-9_])',1,1) AS ZIP_CODE
    FROM AOL_SCHEMA.QUERYDIM
),
-- Validate against ALL real ZIPs before testing a user's single-ZIP rule.
VALID_ZIPS AS (
    SELECT DISTINCT LPAD(TRIM(CAST(POSTAL_CODE AS VARCHAR(10))),5,'0') AS ZIP_CODE
    FROM AOL_SCHEMA.LOCATIONDIM
    WHERE TRIM(CAST(POSTAL_CODE AS VARCHAR(10))) REGEXP_LIKE '^[0-9]{1,5}$'
),
USER_ZIP AS (
    SELECT F.ANONID, MIN(Q.ZIP_CODE) AS ZIP_CODE
    FROM AOL_SCHEMA.FACTS F
    JOIN QUERY_ZIP Q ON F.QUERYID=Q.QUERYID
    JOIN VALID_ZIPS V ON Q.ZIP_CODE=V.ZIP_CODE
    GROUP BY F.ANONID
    HAVING COUNT(DISTINCT Q.ZIP_CODE)=1
),
USERS_LOCATED AS (
    SELECT U.ANONID, Z.STATE_CODE, Z.STATE_NAME
    FROM USER_ZIP U JOIN ZIP_STATE Z ON U.ZIP_CODE=Z.ZIP_CODE
    WHERE Z.STATE_CODE IN (
      'AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL',
      'IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT',
      'NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI',
      'SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY')
),
TIME_CLEAN AS (
    SELECT ID, CAST("YEAR" AS INTEGER) AS YEAR_NO,
      CASE
        WHEN TRIM("MONTH") REGEXP_LIKE '^(0?[1-9]|1[0-2])$'
          THEN CAST(TRIM("MONTH") AS INTEGER)
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='JAN' THEN 1
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='FEB' THEN 2
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='MAR' THEN 3
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='APR' THEN 4
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='MAY' THEN 5
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='JUN' THEN 6
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='JUL' THEN 7
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='AUG' THEN 8
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='SEP' THEN 9
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='OCT' THEN 10
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='NOV' THEN 11
        WHEN UPPER(SUBSTR(TRIM("MONTH"),1,3))='DEC' THEN 12
      END AS MONTH_NO,
      CAST(DAY_OF_THE_MONTH AS INTEGER) AS DAY_NO
    FROM AOL_SCHEMA.TIMEDIM
),
CLICK_ROWS AS (
    SELECT DISTINCT F.ANONID,F.QUERYID,F.TIMEID,F.URLID,
       CASE WHEN TRIM(F.IRANK) REGEXP_LIKE '^[0-9]{1,12}$'
            THEN CAST(TRIM(F.IRANK) AS DECIMAL(18,0)) END AS RANK_NO,
       U.STATE_CODE, U.STATE_NAME, T.YEAR_NO,T.MONTH_NO,T.DAY_NO
    FROM AOL_SCHEMA.FACTS F
    JOIN USERS_LOCATED U ON F.ANONID=U.ANONID
    JOIN TIME_CLEAN T ON F.TIMEID=T.ID
    WHERE F.CLICK=TRUE AND F.URLID IS NOT NULL
),
RANKED AS (
    SELECT C.*, ROW_NUMBER() OVER (
        PARTITION BY ANONID,QUERYID,TIMEID
        ORDER BY CASE WHEN RANK_NO>0 THEN 0 ELSE 1 END,
                 CASE WHEN RANK_NO>0 THEN RANK_NO END, URLID
    ) AS PICK
    FROM CLICK_ROWS C
),
SELECTED_EVENTS AS (
    SELECT * FROM RANKED WHERE PICK=1
),
CATEGORY_MAP AS (
    SELECT DISTINCT UC.URLID, CAT.CATID,
      CASE WHEN UPPER(TRIM(CAT.TOPIC_1))='TOP'
           THEN TRIM(CAT.TOPIC_2)
           ELSE TRIM(CAT.TOPIC_1) END AS CATEGORY
    FROM AOL_SCHEMA.URL_CATEGORY UC
    JOIN AOL_SCHEMA.DMOZ_CATEGORIES CAT ON UC.CATEGORYID=CAT.CATID
),
-- DISTINCT removes repeated broad topic memberships, not different topics.
MEMBERSHIPS AS (
    SELECT DISTINCT E.ANONID,E.QUERYID,E.TIMEID,
           E.STATE_CODE,E.YEAR_NO,E.MONTH_NO,
           COALESCE(C.CATEGORY,'[Unclassified]') AS CATEGORY
    FROM SELECTED_EVENTS E
    LEFT JOIN CATEGORY_MAP C ON E.URLID=C.URLID AND C.CATEGORY IS NOT NULL
),
WEIGHTED AS (
    SELECT M.*, 1.0 / COUNT(*) OVER (
        PARTITION BY ANONID,QUERYID,TIMEID
    ) AS TOPIC_WEIGHT
    FROM MEMBERSHIPS M
),
TOPIC_TOTALS AS (
    SELECT STATE_CODE,YEAR_NO,MONTH_NO,CATEGORY,
           GROUPING(STATE_CODE) AS G_STATE,
           GROUPING(YEAR_NO) AS G_YEAR,
           GROUPING(MONTH_NO) AS G_MONTH,
           COUNT(*) AS EVENTS_WITH_TOPIC,
           COUNT(DISTINCT ANONID) AS USERS_WITH_TOPIC,
           SUM(TOPIC_WEIGHT) AS WEIGHTED_EVENTS
    FROM WEIGHTED
    GROUP BY GROUPING SETS (
        (STATE_CODE,YEAR_NO,MONTH_NO,CATEGORY),
        (STATE_CODE,CATEGORY),
        (YEAR_NO,MONTH_NO,CATEGORY),
        (CATEGORY)
    )
),
-- Denominators come from events BEFORE the category expansion.
DENOMINATORS AS (
    SELECT STATE_CODE,YEAR_NO,MONTH_NO,
           GROUPING(STATE_CODE) AS G_STATE,
           GROUPING(YEAR_NO) AS G_YEAR,
           GROUPING(MONTH_NO) AS G_MONTH,
           COUNT(*) AS TOTAL_EVENTS,
           COUNT(DISTINCT ANONID) AS TOTAL_USERS,
           MIN(DAY_NO) AS FIRST_OBSERVED_DAY,
           MAX(DAY_NO) AS LAST_OBSERVED_DAY,
           COUNT(DISTINCT DAY_NO) AS OBSERVED_DAY_NUMBERS
    FROM SELECTED_EVENTS
    GROUP BY GROUPING SETS (
        (STATE_CODE,YEAR_NO,MONTH_NO),
        (STATE_CODE), (YEAR_NO,MONTH_NO), ()
    )
)
SELECT
    'LOWEST_RANK_PROXY_NOT_CHRONOLOGICAL' AS CLICK_METHOD,
    CASE WHEN A.G_STATE=0 AND A.G_YEAR=0 THEN 'STATE_MONTH'
         WHEN A.G_STATE=0 THEN 'STATE_ALL_MONTHS'
         WHEN A.G_YEAR=0 THEN 'ALL_STATES_MONTH'
         ELSE 'ALL_STATES_ALL_MONTHS' END AS SUMMARY_LEVEL,
    A.STATE_CODE,A.YEAR_NO,A.MONTH_NO,A.CATEGORY,
    A.EVENTS_WITH_TOPIC,A.USERS_WITH_TOPIC,
    ROUND(A.WEIGHTED_EVENTS,6) AS WEIGHTED_EVENTS,
    D.TOTAL_EVENTS,D.TOTAL_USERS,
    ROUND(100.0*A.EVENTS_WITH_TOPIC/NULLIF(D.TOTAL_EVENTS,0),4) AS TOPIC_REACH_PCT,
    ROUND(100.0*A.WEIGHTED_EVENTS/NULLIF(D.TOTAL_EVENTS,0),4) AS STACKED_SHARE_PCT,
    CASE WHEN A.G_YEAR=0 THEN D.FIRST_OBSERVED_DAY END AS FIRST_OBSERVED_DAY,
    CASE WHEN A.G_YEAR=0 THEN D.LAST_OBSERVED_DAY END AS LAST_OBSERVED_DAY,
    CASE WHEN A.G_YEAR=0 THEN D.OBSERVED_DAY_NUMBERS END AS OBSERVED_DAYS
FROM TOPIC_TOTALS A
JOIN DENOMINATORS D
  ON A.G_STATE=D.G_STATE AND A.G_YEAR=D.G_YEAR AND A.G_MONTH=D.G_MONTH
 AND (A.STATE_CODE=D.STATE_CODE OR (A.STATE_CODE IS NULL AND D.STATE_CODE IS NULL))
 AND (A.YEAR_NO=D.YEAR_NO OR (A.YEAR_NO IS NULL AND D.YEAR_NO IS NULL))
 AND (A.MONTH_NO=D.MONTH_NO OR (A.MONTH_NO IS NULL AND D.MONTH_NO IS NULL))
ORDER BY SUMMARY_LEVEL,STATE_CODE,YEAR_NO,MONTH_NO,WEIGHTED_EVENTS DESC;

/* EXPORT AND INTERPRET
Export Section B's complete result with column headings to CSV.
Suggested name: Okum_State_Month_Topics.csv
Do not export only the first visible page of the DataGrip result grid.

CHART 1 — 100% stacked bars
Filter SUMMARY_LEVEL='STATE_ALL_MONTHS'. X=STATE_CODE;
Y=STACKED_SHARE_PCT; color=CATEGORY. Choose a fixed common category set,
group small categories as Other consistently, keep Unclassified separate.
Show TOTAL_USERS and TOTAL_EVENTS beside each state's bar.
Never combine summary levels, or sum TOTAL_EVENTS across topic rows.
For a readable main chart, select the 10 states with the most TOTAL_EVENTS
and include all states in an appendix. Do not select by dramatic results.

CHART 2 — monthly trends
Filter SUMMARY_LEVEL='ALL_STATES_MONTH', or use STATE_MONTH panels to
compare individual states. X=YEAR_NO + MONTH_NO in chronological order;
Y=STACKED_SHARE_PCT; line=CATEGORY. Keep topic colors fixed across charts.
Select 4-6 categories using their all-period weighted counts, not growth.
Create missing topic rows with zero ONLY when that state/month has a
positive known event denominator. A missing state/month is missing data,
not zero. Never connect missing months as if they were consecutive.

CHANGE TABLE
For each state/category and consecutive observed calendar months:
CHANGE_PP = current STACKED_SHARE_PCT - previous STACKED_SHARE_PCT.
An increase from 10% to 15% is +5 percentage points, not +5 percent.
Rank increases and decreases only after inspecting sample sizes, coverage
and complete months. 'Emerging' means observed increasing share here,
not proof of a national trend or a causal explanation.

VALIDATION BEFORE PRESENTATION
- Inspect unique IDs in dimensions and missing time/URL joins.
- Verify one selected row per (ANONID,QUERYID,TIMEID).
- Inspect tied/missing ranks; compare results under other plausible choices.
- Verify total topic weights per event=1, and aggregate weighted counts
  equal TOTAL_EVENTS within each summary group (allow rounding tolerance).
- Stacked shares per group sum to 100%; reach percentages need not.
- Check null MONTH_NO and observed day coverage. Limit trend comparison to
  comparable periods; partial-month shares can still have composition bias.
- Report Unclassified share by state and month: changing classification
  coverage can look like changing interests.
- Quantify users lost at each geography step and events lost at joins.
- Inspect low sample states (e.g. fewer than 30 users as a flagged heuristic,
  not a statistical guarantee), and single-user concentration.
- Recompute a small known example manually before accepting output.

ILLUSTRATION ONLY, NOT AOL RESULTS:
One query with Arts + Shopping contributes 0.5 to each; another with Arts
alone contributes 1.0 to Arts. With two events: weighted Arts=75%,
Shopping=25%; reach Arts=100%, Shopping=50%.

FINAL WRITE-UP SHOULD INCLUDE
Question; source tables and inferred geography; event unit; click policy;
category weighting; GROUPING SETS levels; sample and coverage; state chart;
monthly chart; largest supported differences and percentage-point changes;
limitations; actual problems and fixes; AI-use disclosure.
Do not fill results with the board's word-count or population rankings:
those answer other questions and are not topic-share evidence.
*/
