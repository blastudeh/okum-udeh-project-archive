"""Reproduce cleaned GeoNames data. Usage: python prepare_zip.py path/to/US.zip"""
import csv, zipfile, collections, json, sys, hashlib
from pathlib import Path
p=Path(__file__).resolve().parent; out=p/'data';out.mkdir(exist_ok=True)
source=Path(sys.argv[1]) if len(sys.argv)>1 else out/'US_original.zip'
with zipfile.ZipFile(source) as z:
 raw=z.read('US.txt');rows=list(csv.reader(raw.decode('utf-8-sig').splitlines(),delimiter='\t'))
 (out/'GeoNames_README.txt').write_bytes(z.read('readme.txt'))
assert all(len(r)==12 for r in rows), 'Unexpected column count'
states=set('AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split())
kept=collections.defaultdict(list); excluded=[]
for r in rows:
 if r[0]!='US' or r[4] not in states or len(r[1])!=5 or not r[1].isdigit():excluded.append(r)
 else:kept[r[1]].append(r)
clean=[];ambiguous=[]
for code,rs in sorted(kept.items()):
 if len({(r[4],r[6]) for r in rs})!=1:ambiguous.extend(rs);continue
 r=rs[0]
 clean.append([code,r[2],r[3],r[4],r[5],r[6],r[9],r[10]])
head=['ZIP_CODE','PLACE_NAME','STATE_NAME','STATE_CODE','COUNTY_NAME','COUNTY_CODE','LATITUDE','LONGITUDE']
for name,header,data in [('zip_clean.csv',head,clean),('zip_excluded.tsv',[],excluded),('zip_ambiguous.tsv',[],ambiguous)]:
 with (out/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f,delimiter='\t' if name.endswith('.tsv') else ',')
  if header:w.writerow(header)
  w.writerows(data)
stats={'source_sha256':hashlib.sha256(raw).hexdigest(),'raw_rows':len(rows),'distinct_raw_zips':len({r[1] for r in rows}),'missing_state_rows':sum(not r[4] for r in rows),'excluded_rows':len(excluded),'ambiguous_valid_rows':len(ambiguous),'clean_rows':len(clean),'clean_leading_zero_zips':sum(r[0].startswith('0') for r in clean),'scope':'50 states plus DC; valid state records preferred over blank-state duplicate records; no residence inference'}
(out/'zip_quality.json').write_text(json.dumps(stats,indent=2)+'\n')
assert len(clean)==len({r[0] for r in clean})
print(json.dumps(stats,indent=2))
