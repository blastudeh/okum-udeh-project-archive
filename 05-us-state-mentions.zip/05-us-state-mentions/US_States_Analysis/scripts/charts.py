from pathlib import Path
import pandas as pd,json,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path(__file__).resolve().parents[1];out=r/'charts'
d=pd.read_csv(r/'results/state_summary.csv');f=json.loads((r/'results/facts.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.labelcolor':'#173647','text.color':'#173647'})
def save(name):plt.tight_layout();plt.savefig(out/(name+'.png'),dpi=180,bbox_inches='tight');plt.close()
a=d.head(10).sort_values('mentions');fig,ax=plt.subplots(figsize=(9,5));ax.barh(a.state_name,a.mentions/1000,color='#087f8c');ax.set_xlabel('State-event mentions (thousands)');ax.set_xlim(0,138)
for i,n in enumerate(a.mentions):ax.text(n/1000+1,i,f'{n:,}',va='center',fontsize=10)
save('volume')
a=d.sort_values('attention_index',ascending=False).head(10).sort_values('attention_index');fig,ax=plt.subplots(figsize=(9,5));ax.barh(a.state_name,a.attention_index,color='#087f8c');ax.axvline(1,color='#c47f20',linestyle='--');ax.set_xlabel('Mention share / population share (1 = proportional baseline)')
for i,n in enumerate(a.attention_index):ax.text(n+.025,i,f'{n:.2f}',va='center',fontsize=10)
ax.set_xlim(0,max(a.attention_index)*1.18);save('index')
fig,ax=plt.subplots(figsize=(9,5.5));ax.scatter(d.population_2006/1e6,d.mentions/1000,color='#087f8c',s=40,alpha=.75)
for _,x in d[d.state_name.isin(['Florida','California','Texas','New York','Ohio'])].iterrows():ax.annotate(x.state_name,(x.population_2006/1e6,x.mentions/1000),xytext=(4,6),textcoords='offset points',fontsize=10)
ax.set_xlabel('Resident population, Census vintage 2006 (millions)');ax.set_ylabel('State-event mentions (thousands)');ax.set_xlim(0,41);ax.set_ylim(0,133);ax.text(.04,.94,f"Pearson r = {f['pearson_all50']:.3f}\n50 states",transform=ax.transAxes,va='top');save('population')
m=pd.read_csv(r/'results/monthly.csv');fig,ax=plt.subplots(figsize=(9,5));
for name in d.head(5).state_name:
 v=m[m.state_name==name].sort_values('search_month');ax.plot(v.search_month,v.mentions/1000,marker='o',label=name)
ax.set_xlabel('Month in 2006');ax.set_ylabel('State-event mentions (thousands)');ax.set_ylim(bottom=0);ax.legend(ncol=3,frameon=False);save('monthly')
t=pd.read_csv(r/'results/theme_rates.csv');names=['Florida','Texas','New York','Ohio','California'];cats=['Tourism','Education','Housing','Government'];fig,ax=plt.subplots(figsize=(9,5));import numpy as np
for j,k in enumerate(cats):
 vals=[100*t[(t.state_name==n)&(t.theme==k)].theme_share.iloc[0] for n in names];ax.bar(np.arange(5)+(j-1.5)*.19,vals,width=.19,label=k)
ax.set_xticks(range(5),names);ax.set_ylabel('Share of state-event mentions (%)');ax.legend(ncol=4,frameon=False);save('themes')
z=pd.read_csv(r/'results/q5_sessions.csv');fig,ax=plt.subplots(figsize=(8,4.5));ax.bar(['Previous event has\nno state name','Previous event has\na state name'],z.current_state_share*100,color=['#8296a0','#087f8c']);ax.set_ylabel('Current event mentions a state (%)');ax.set_ylim(0,max(z.current_state_share)*125)
for i,v in enumerate(z.current_state_share):ax.text(i,v*100+.6,f'{v*100:.1f}%',ha='center')
save('sessions')
print('Six charts saved')
