"""Shared Pygame window, text and keyboard handling for Exercise 1."""
from pathlib import Path
import argparse
import pygame

WIDTH, HEIGHT = 900, 620
BG = '#132330'
WHITE = '#edf4f7'
YELLOW = '#ffd15c'


def text(screen, message, x, y, size=23, color=WHITE):
    screen.blit(pygame.font.Font(None, size).render(message, True, color), (x, y))


def run(game_class):
    parser = argparse.ArgumentParser()
    parser.add_argument('--demo-screenshot', action='store_true',
                        help='Run a short scripted demonstration, save an image and exit.')
    args = parser.parse_args()
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(game_class.title + ' | Python - Exercise 1')
    game = game_class()
    clock = pygame.time.Clock()
    paused = False
    frame = 0
    alive = True
    screenshot = False
    try:
        while alive:
            dt = 1 / 60 if args.demo_screenshot else min(clock.tick(60) / 1000, 0.04)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    alive = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        alive = False
                    elif event.key == pygame.K_r:
                        game = game_class()
                        paused = False
                    elif event.key == pygame.K_p:
                        paused = not paused
                    elif event.key == pygame.K_F12:
                        screenshot = True
                    elif not paused:
                        game.key(event.key)
                elif event.type == pygame.MOUSEBUTTONDOWN and not paused:
                    game.key(pygame.K_SPACE)
            if not paused:
                game.update(dt, pygame.key.get_pressed(), frame if args.demo_screenshot else None)
            screen.fill(BG)
            text(screen, 'EXERCISE 1 / PYTHON + PYGAME', 25, 17, 20, YELLOW)
            text(screen, game.title, 25, 44, 34)
            text(screen, game.score_text(), 620, 48, 25, YELLOW)
            game.draw(screen)
            text(screen, game.message(), 25, 540, 23)
            text(screen, game.controls, 25, 570, 21, '#b8cbd7')
            text(screen, 'R: restart   P: pause   F12: save screenshot   Esc: exit', 25, 596, 20, '#b8cbd7')
            if paused:
                pygame.draw.rect(screen, BG, (325, 255, 250, 70), border_radius=10)
                text(screen, 'PAUSED - press P', 350, 278, 29)
            pygame.display.flip()
            frame += 1
            if args.demo_screenshot and frame == 150:
                screenshot = True
                alive = False
            if screenshot:
                folder = Path(__file__).resolve().parent / 'screenshots'
                folder.mkdir(exist_ok=True)
                destination = folder / (game.filename + '.png')
                pygame.image.save(screen, str(destination))
                print('Screenshot saved:', destination)
                screenshot = False
    finally:
        pygame.quit()
