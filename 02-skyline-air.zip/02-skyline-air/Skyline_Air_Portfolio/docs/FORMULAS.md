# Exact workbook helper formulas

Extracted from Cleaned_Data row 2. Row references change when filled down. These formulas are evidence of the delivered implementation.

## QualityFlag

```excel
=IF(OR(OR(K2="Unknown",K2=""),AND(ISNUMBER(I2),OR(I2<-60,I2>1440)),AND(ISNUMBER(M2),M2<=0),AND(L2="Completed",NOT(ISNUMBER(H2))),AND(L2="Completed",NOT(ISNUMBER(J2))),AND(L2="Completed",NOT(ISNUMBER(I2))),P2=1,AND(R2=1,J2>=15,K2="None recorded"),AND(L2="Cancelled",OR(ISNUMBER(H2),ISNUMBER(I2),ISNUMBER(J2)))),IF(OR(K2="Unknown",K2=""),"Missing cause; ","")&IF(AND(ISNUMBER(I2),OR(I2<-60,I2>1440)),"Unverified departure outlier; ","")&IF(AND(ISNUMBER(M2),M2<=0),"Invalid distance; ","")&IF(AND(L2="Completed",NOT(ISNUMBER(H2))),"Missing actual departure; ","")&IF(AND(L2="Completed",NOT(ISNUMBER(J2))),"Missing arrival delay; ","")&IF(AND(L2="Completed",NOT(ISNUMBER(I2))),"Missing departure delay; ","")&IF(P2=1,"Time and departure delay mismatch; ","")&IF(AND(R2=1,J2>=15,K2="None recorded"),"Arrival delayed with no cause recorded; ","")&IF(AND(L2="Cancelled",OR(ISNUMBER(H2),ISNUMBER(I2),ISNUMBER(J2))),"Cancelled with flight measures; ",""),"OK")
```

## TimeMismatch

```excel
=IF(AND(L2="Completed",ISNUMBER(I2),ISNUMBER(G2),ISNUMBER(H2)),IF(ABS(MOD((H2-G2)*1440-I2+720,1440)-720)>0.01,1,0),0)
```

## DepartureEligible

```excel
=IF(AND(L2="Completed",ISNUMBER(I2),I2>=-60,I2<=1440,P2=0),1,0)
```

## ArrivalEligible

```excel
=IF(AND(L2="Completed",ISNUMBER(J2),J2>=-60,J2<=1440),1,0)
```

## MonthStart

```excel
=DATE(YEAR(B2),MONTH(B2),1)
```

## MonthName

```excel
=TEXT(S2,"yyyy-mm")
```

## WeekdayNumber

```excel
=WEEKDAY(B2,2)
```

## WeekdayName

```excel
=TEXT(B2,"dddd")
```

## ScheduledHour

```excel
=HOUR(G2)
```

## TimeOfDayBand

```excel
=IF(W2<6,"Night 00-05",IF(W2<12,"Morning 06-11",IF(W2<18,"Afternoon 12-17","Evening 18-23")))
```

## DepartureOnTime

```excel
=IF(Q2=1,IF(I2<15,1,0),"")
```

## ArrivalOnTime

```excel
=IF(R2=1,IF(J2<15,1,0),"")
```

## PositiveDepartureMin

```excel
=IF(Q2=1,MAX(0,I2),"")
```

## PositiveArrivalMin

```excel
=IF(R2=1,MAX(0,J2),"")
```

## CompletedFlag

```excel
=IF(L2="Completed",1,0)
```

## CancelledFlag

```excel
=IF(L2="Cancelled",1,0)
```

## Selected

```excel
=IF(AND(OR(Dashboard!$B$5="All",T2=Dashboard!$B$5),OR(Dashboard!$F$5="All",D2=Dashboard!$F$5),OR(Dashboard!$J$5="All",E2=Dashboard!$J$5),OR(Dashboard!$N$5="All",F2=Dashboard!$N$5)),1,0)
```

