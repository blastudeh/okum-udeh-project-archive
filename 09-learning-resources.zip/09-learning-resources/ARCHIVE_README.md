# Data science learning guides

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed educational documents

Four completed guides: Mathematical Models (1–11), Statistics/R (six lessons), AI study lessons and Data Science Platforms.

## Process

1. Recover completed authored guides.
2. Group by subject.
3. Preserve diagrams and explanations in the original PDFs.

## Verification

Four PDF artifacts recovered. These are learning materials, not evidence of passed exams or independently validated solutions.

## Limits and provenance

Source lecture decks and personal university records are not included. AI-assisted explanations may require checking against course material.
