# Football fixtures and comparison workbooks

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed dated spreadsheet outputs

Representative workbooks from the recurring fixture, score-comparison and prediction-analysis work.

## Process

1. Collect dated fixture/source observations.
2. Align competition, match and time fields.
3. Separate source predictions from estimated values.
4. Record methodology and missing information.

## Verification

Four completed dated workbooks recovered. Their analysis represents the date in each filename, not live schedules.

## Limits and provenance

Many daily variants were generated; this archive groups them as one project family rather than calling every date a new project. Predictions are not validated betting performance or guaranteed outcomes. No current fixture or profitability claims are made.
