# US state search-interest analysis

Owner: Okum Udeh. Archived 8 November 2026. ChatGPT-assisted work.

**Status:** Completed local analysis; Exasol port unverified

State-name mention analysis with population normalization, scripts, SQL, charts, report and presentation.

## Process

1. Match full state names using documented boundaries.
2. Aggregate event-state pairs.
3. Join population reference data.
4. Calculate normalized interest and correlations.
5. Report ambiguity and population limitations.

## Verification

Recovered results document 28,037,812 cleaned events, 1,132,545 state-mention events and 1,137,864 event-state pairs. Saved report gives population correlation 0.8093. Not rerun over raw logs in this archival pass.

## Limits and provenance

A search can mention several states. Mentioned states are not residences. This is distinct from ZIP matching and from the later Exasol question-3 export. Exasol deployment remains unverified.
